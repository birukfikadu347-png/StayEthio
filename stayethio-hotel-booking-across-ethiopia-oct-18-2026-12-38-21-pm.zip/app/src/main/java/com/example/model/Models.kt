package com.example.model

import androidx.annotation.DrawableRes

enum class UserRole {
    GUEST,
    HOTEL_OWNER,
    ADMIN
}

enum class PaymentType(val displayName: String, val description: String) {
    TELEBIRR("Telebirr", "Fast mobile payment via Ethio Telecom Telebirr super-app"),
    BANK_TRANSFER("Bank Transfer", "Direct transfer via CBE, Awash, or Bank of Abyssinia"),
    CASH_ON_ARRIVAL("Cash on Arrival", "Pay directly in ETB or USD at hotel front reception desk")
}

enum class BookingStatus(val label: String) {
    CONFIRMED("Confirmed"),
    PENDING_APPROVAL("Pending Review"),
    CHECKED_IN("Checked In"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

data class RoomType(
    val id: String,
    val name: String,
    val description: String,
    val bedType: String,
    val maxGuests: Int,
    val pricePerNightEtb: Double,
    val sizeSqMeters: Int,
    val amenities: List<String>,
    @DrawableRes val imageRes: Int,
    val availableCount: Int = 5
)

data class Review(
    val id: String,
    val authorName: String,
    val cityOrCountry: String,
    val rating: Double,
    val date: String,
    val comment: String
)

data class Hotel(
    val id: String,
    val name: String,
    val city: String,
    val subCityOrArea: String,
    val fullAddress: String,
    val starRating: Int,
    val reviewScore: Double,
    val reviewCount: Int,
    val startingPriceEtb: Double,
    @DrawableRes val mainImageRes: Int,
    val galleryImages: List<Int>,
    val description: String,
    val highlights: List<String>,
    val amenities: List<String>,
    val rooms: List<RoomType>,
    val isFeatured: Boolean = false,
    val isVerified: Boolean = true,
    val ownerId: String = "partner_1",
    val distanceToAirportKm: Double? = null,
    val cancellationPolicy: String = "Free cancellation up to 48 hours before check-in"
)

data class Booking(
    val id: String,
    val referenceCode: String,
    val hotelId: String,
    val hotelName: String,
    val hotelCity: String,
    @DrawableRes val hotelImageRes: Int,
    val roomTypeName: String,
    val checkInDate: String,
    val checkOutDate: String,
    val nightsCount: Int,
    val guestCount: Int,
    val guestFullName: String,
    val guestPhone: String,
    val guestEmail: String,
    val specialRequests: String,
    val subtotalEtb: Double,
    val taxesEtb: Double,
    val totalAmountEtb: Double,
    val paymentType: PaymentType,
    val paymentStatus: String, // "Paid", "Pending Verification", "Due on Arrival"
    val bookingStatus: BookingStatus,
    val createdAt: String,
    val bankTransactionRef: String? = null,
    val telebirrPhone: String? = null
)

data class SearchCriteria(
    val selectedCity: String = "All Cities",
    val checkInDate: String = "Oct 24, 2026",
    val checkOutDate: String = "Oct 27, 2026",
    val nights: Int = 3,
    val guestCount: Int = 2,
    val selectedStar: Int? = null,
    val maxPriceEtb: Double = 35000.0,
    val requiredAmenity: String? = null
)
