package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookOnline
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StayEthioRepository
import com.example.model.Booking
import com.example.model.Hotel
import com.example.model.RoomType
import com.example.model.UserRole
import com.example.ui.components.BookingVoucherDialog
import com.example.ui.components.TopBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.BookingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HotelDetailScreen
import com.example.ui.screens.MyBookingsScreen
import com.example.ui.screens.OwnerDashboardScreen
import com.example.ui.theme.BorderNeutral
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SurfaceNeutral
import com.example.ui.theme.TealDark
import com.example.ui.theme.TealLight
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.TealSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                StayEthioApp()
            }
        }
    }
}

@Composable
fun StayEthioApp() {
    var currentScreen by remember { mutableStateOf("home") } // "home", "hotel_detail", "booking", "my_bookings"
    var selectedHotel by remember { mutableStateOf<Hotel?>(null) }
    var selectedRoom by remember { mutableStateOf<RoomType?>(null) }
    var latestBookingVoucher by remember { mutableStateOf<Booking?>(null) }

    // Hardware Back Button handling
    BackHandler(enabled = currentScreen != "home" || StayEthioRepository.currentRole != UserRole.GUEST) {
        if (currentScreen == "booking") {
            currentScreen = "hotel_detail"
        } else if (currentScreen == "hotel_detail" || currentScreen == "my_bookings") {
            currentScreen = "home"
        } else if (StayEthioRepository.currentRole != UserRole.GUEST) {
            StayEthioRepository.currentRole = UserRole.GUEST
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            TopBar(
                onNavigateHome = {
                    StayEthioRepository.currentRole = UserRole.GUEST
                    currentScreen = "home"
                },
                onNavigateBookings = {
                    StayEthioRepository.currentRole = UserRole.GUEST
                    currentScreen = "my_bookings"
                },
                currentScreen = currentScreen
            )
        },
        bottomBar = {
            if (StayEthioRepository.currentRole == UserRole.GUEST) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.White,
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BottomNavItem(
                            icon = Icons.Default.Explore,
                            label = "Discover",
                            isSelected = currentScreen == "home",
                            onClick = { currentScreen = "home" }
                        )

                        BottomNavItem(
                            icon = Icons.Default.BookOnline,
                            label = "My Stays",
                            badgeCount = StayEthioRepository.bookings.size,
                            isSelected = currentScreen == "my_bookings",
                            onClick = { currentScreen = "my_bookings" }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.White)
        ) {
            when (StayEthioRepository.currentRole) {
                UserRole.HOTEL_OWNER -> {
                    OwnerDashboardScreen()
                }

                UserRole.ADMIN -> {
                    AdminDashboardScreen()
                }

                UserRole.GUEST -> {
                    when (currentScreen) {
                        "home" -> {
                            HomeScreen(
                                onSelectHotel = { hotel ->
                                    selectedHotel = hotel
                                    currentScreen = "hotel_detail"
                                }
                            )
                        }

                        "hotel_detail" -> {
                            selectedHotel?.let { hotel ->
                                HotelDetailScreen(
                                    hotel = hotel,
                                    onBack = { currentScreen = "home" },
                                    onProceedToBooking = { room ->
                                        selectedRoom = room
                                        currentScreen = "booking"
                                    }
                                )
                            } ?: run {
                                currentScreen = "home"
                            }
                        }

                        "booking" -> {
                            if (selectedHotel != null && selectedRoom != null) {
                                BookingScreen(
                                    hotel = selectedHotel!!,
                                    room = selectedRoom!!,
                                    onBack = { currentScreen = "hotel_detail" },
                                    onBookingSuccess = { newBooking ->
                                        latestBookingVoucher = newBooking
                                        currentScreen = "my_bookings"
                                    }
                                )
                            } else {
                                currentScreen = "home"
                            }
                        }

                        "my_bookings" -> {
                            MyBookingsScreen(
                                onBack = { currentScreen = "home" },
                                onExploreHotels = { currentScreen = "home" }
                            )
                        }
                    }
                }
            }

            // Show latest generated booking voucher if just booked
            latestBookingVoucher?.let { voucher ->
                BookingVoucherDialog(
                    booking = voucher,
                    onDismiss = { latestBookingVoucher = null }
                )
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    badgeCount: Int? = null,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        if (badgeCount != null && badgeCount > 0) {
            BadgedBox(
                badge = {
                    Badge(
                        containerColor = TealPrimary,
                        contentColor = Color.White
                    ) {
                        Text(text = "$badgeCount", fontSize = 9.sp)
                    }
                }
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) TealPrimary else TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        } else {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) TealPrimary else TextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) TealDark else TextSecondary
        )
    }
}

