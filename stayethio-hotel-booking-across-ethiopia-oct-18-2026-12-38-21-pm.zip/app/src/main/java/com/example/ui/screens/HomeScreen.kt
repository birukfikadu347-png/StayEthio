package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.StayEthioRepository
import com.example.model.Hotel
import com.example.ui.components.HotelCard
import com.example.ui.theme.AmberStar
import com.example.ui.theme.BorderNeutral
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SurfaceNeutral
import com.example.ui.theme.TealDark
import com.example.ui.theme.TealLight
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.TealSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onSelectHotel: (Hotel) -> Unit
) {
    var isCityMenuOpen by remember { mutableStateOf(false) }
    var isFilterSheetOpen by remember { mutableStateOf(false) }
    var tempMaxPrice by remember { mutableFloatStateOf(StayEthioRepository.searchCriteria.maxPriceEtb.toFloat()) }
    var tempStarRating by remember { mutableStateOf<Int?>(StayEthioRepository.searchCriteria.selectedStar) }

    // Filter hotels by search criteria
    val filteredHotels = StayEthioRepository.hotels.filter { hotel ->
        val cityMatch = StayEthioRepository.searchCriteria.selectedCity == "All Cities" ||
                hotel.city.equals(StayEthioRepository.searchCriteria.selectedCity, ignoreCase = true)
        val priceMatch = hotel.startingPriceEtb <= StayEthioRepository.searchCriteria.maxPriceEtb
        val starMatch = StayEthioRepository.searchCriteria.selectedStar == null ||
                hotel.starRating >= StayEthioRepository.searchCriteria.selectedStar!!
        val guestMatch = hotel.rooms.any { it.maxGuests >= StayEthioRepository.searchCriteria.guestCount }
        
        cityMatch && priceMatch && starMatch && guestMatch
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Hero Section with Image & Overlay
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hotel_hero),
                    contentDescription = "Ethiopian Luxury Lodges & Stays",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                )

                // Dark gradient scrim
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    NavyDark.copy(alpha = 0.55f),
                                    NavyDark.copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                // Hero Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = TealPrimary.copy(alpha = 0.85f),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "PREMIER HOSPITALITY IN ETHIOPIA",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Text(
                        text = "Discover & Book Stays\nAcross Ethiopia",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 32.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Luxury resorts, business suites & highland lodges in Addis Ababa, Bishoftu, Lalibela & Lake Tana.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        maxLines = 2
                    )
                }
            }
        }

        // Search & Filter Floating Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(top = (-24).dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Row 1: City Dropdown
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SurfaceNeutral,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isCityMenuOpen = true }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "City",
                                    tint = TealPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Destination in Ethiopia",
                                        fontSize = 10.sp,
                                        color = TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = StayEthioRepository.searchCriteria.selectedCity,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyPrimary
                                    )
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = isCityMenuOpen,
                            onDismissRequest = { isCityMenuOpen = false }
                        ) {
                            StayEthioRepository.ethiopianCities.forEach { city ->
                                DropdownMenuItem(
                                    text = { Text(city, fontWeight = if (city == StayEthioRepository.searchCriteria.selectedCity) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(selectedCity = city)
                                        isCityMenuOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 2: Dates and Guests in 2 Columns
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Dates
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SurfaceNeutral,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = "Dates",
                                    tint = TealPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Check-in / Out",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = "Oct 24 - 27 (3N)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyPrimary
                                    )
                                }
                            }
                        }

                        // Guests Counter
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SurfaceNeutral,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.People,
                                        contentDescription = "Guests",
                                        tint = TealPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(
                                            text = "Guests",
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                        Text(
                                            text = "${StayEthioRepository.searchCriteria.guestCount} Guests",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NavyPrimary
                                        )
                                    }
                                }

                                Row {
                                    Text(
                                        text = "-",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (StayEthioRepository.searchCriteria.guestCount > 1) NavyPrimary else TextMuted,
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .clickable(enabled = StayEthioRepository.searchCriteria.guestCount > 1) {
                                                StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(
                                                    guestCount = StayEthioRepository.searchCriteria.guestCount - 1
                                                )
                                            }
                                            .padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "+",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyPrimary,
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .clickable {
                                                StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(
                                                    guestCount = StayEthioRepository.searchCriteria.guestCount + 1
                                                )
                                            }
                                            .padding(horizontal = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Row 3: Action Buttons (Search & Filter)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isFilterSheetOpen = true },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filters",
                                tint = NavyPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (StayEthioRepository.searchCriteria.selectedStar != null) "Filtered" else "Filters",
                                color = NavyPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { /* Already dynamic */ },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NavyPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                modifier = Modifier.size(16.dp),
                                tint = TealLight
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Search Hotels (${filteredHotels.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Quick Ethiopian Destination Pills
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp, bottom = 12.dp)
            ) {
                Text(
                    text = "Popular Ethiopian Destinations",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StayEthioRepository.ethiopianCities.forEach { city ->
                        val isSelected = StayEthioRepository.searchCriteria.selectedCity == city
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) TealPrimary else SurfaceNeutral,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) TealPrimary else BorderNeutral
                            ),
                            modifier = Modifier.clickable {
                                StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(selectedCity = city)
                            }
                        ) {
                            Text(
                                text = city,
                                color = if (isSelected) Color.White else NavyPrimary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Ethiopian Payment Security Strip
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                color = TealSubtle,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Trusted Ethiopian Payment Methods",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TealDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PaymentBadge(icon = Icons.Default.PhoneAndroid, title = "Telebirr Mobile")
                        PaymentBadge(icon = Icons.Default.AccountBalance, title = "CBE / Awash Transfer")
                        PaymentBadge(icon = Icons.Default.Paid, title = "Cash on Arrival")
                    }
                }
            }
        }

        // Hotels Section Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (StayEthioRepository.searchCriteria.selectedCity == "All Cities")
                            "Featured Ethiopian Hotels & Lodges"
                        else
                            "Hotels in ${StayEthioRepository.searchCriteria.selectedCity}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "${filteredHotels.size} verified properties available for booking",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                if (StayEthioRepository.searchCriteria.selectedCity != "All Cities" ||
                    StayEthioRepository.searchCriteria.selectedStar != null) {
                    Text(
                        text = "Reset Filters",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TealPrimary,
                        modifier = Modifier.clickable {
                            StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(
                                selectedCity = "All Cities",
                                selectedStar = null,
                                maxPriceEtb = 35000.0
                            )
                        }
                    )
                }
            }
        }

        // Empty State
        if (filteredHotels.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "No hotels found matching your search.",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing filters or switching destination cities.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(
                                selectedCity = "All Cities",
                                selectedStar = null,
                                maxPriceEtb = 35000.0
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                    ) {
                        Text("Show All Hotels")
                    }
                }
            }
        } else {
            // Hotel Cards
            items(filteredHotels) { hotel ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    HotelCard(
                        hotel = hotel,
                        onClick = { onSelectHotel(hotel) }
                    )
                }
            }
        }
    }

    // Filter Bottom Sheet Modal
    if (isFilterSheetOpen) {
        ModalBottomSheet(
            onDismissRequest = { isFilterSheetOpen = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Filter Hotel Stays",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Star Rating Filter
                Text(
                    text = "Minimum Star Rating",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(null, 3, 4, 5).forEach { star ->
                        val isSelected = tempStarRating == star
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) NavyPrimary else SurfaceNeutral,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { tempStarRating = star }
                        ) {
                            Text(
                                text = if (star == null) "Any" else "$star ★",
                                color = if (isSelected) Color.White else NavyPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Max Price Range
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Max Price per Night",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = StayEthioRepository.formatPrice(tempMaxPrice.toDouble()),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TealDark
                    )
                }

                Slider(
                    value = tempMaxPrice,
                    onValueChange = { tempMaxPrice = it },
                    valueRange = 5000f..35000f,
                    steps = 6,
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        thumbColor = TealPrimary,
                        activeTrackColor = TealPrimary
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            tempStarRating = null
                            tempMaxPrice = 35000f
                            StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(
                                selectedStar = null,
                                maxPriceEtb = 35000.0
                            )
                            isFilterSheetOpen = false
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Reset", color = NavyPrimary)
                    }

                    Button(
                        onClick = {
                            StayEthioRepository.searchCriteria = StayEthioRepository.searchCriteria.copy(
                                selectedStar = tempStarRating,
                                maxPriceEtb = tempMaxPrice.toDouble()
                            )
                            isFilterSheetOpen = false
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Apply Filters")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun PaymentBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = TealDark,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = NavyPrimary
        )
    }
}
