package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StayEthioRepository
import com.example.model.Booking
import com.example.model.Hotel
import com.example.model.PaymentType
import com.example.model.RoomType
import com.example.ui.theme.BorderNeutral
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SurfaceNeutral
import com.example.ui.theme.TealDark
import com.example.ui.theme.TealLight
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.TealSubtle
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun BookingScreen(
    hotel: Hotel,
    room: RoomType,
    onBack: () -> Unit,
    onBookingSuccess: (Booking) -> Unit
) {
    var fullName by remember { mutableStateOf("Yakin Yohannes") }
    var phone by remember { mutableStateOf("+251 91 123 4567") }
    var email by remember { mutableStateOf("yakin.travel@example.com") }
    var specialRequests by remember { mutableStateOf("Arriving via Bole flight ET302. Please arrange complimentary airport pickup.") }
    
    var selectedPayment by remember { mutableStateOf(PaymentType.TELEBIRR) }
    var telebirrPhone by remember { mutableStateOf("+251 91 123 4567") }
    var selectedBank by remember { mutableStateOf("Commercial Bank of Ethiopia (CBE)") }
    var bankRefNumber by remember { mutableStateOf("CBE-TX-928472") }
    
    var isProcessing by remember { mutableStateOf(false) }

    val nights = StayEthioRepository.searchCriteria.nights
    val subtotal = room.pricePerNightEtb * nights
    val vatTaxes = subtotal * 0.15
    val total = subtotal + vatTaxes

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Top Navigation Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.White,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = NavyPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "Complete Your Reservation",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "${hotel.name} · ${hotel.city}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Scrollable Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Stay Overview Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceNeutral),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = hotel.mainImageRes),
                        contentDescription = hotel.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(70.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = hotel.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                        Text(
                            text = room.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TealDark
                        )
                        Text(
                            text = "${StayEthioRepository.searchCriteria.checkInDate} — ${StayEthioRepository.searchCriteria.checkOutDate} ($nights nights)",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = "${StayEthioRepository.searchCriteria.guestCount} Guests · ${room.bedType}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Guest Contact Details
            Text(
                text = "Guest Information",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Name (as on Passport / Kebele ID)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TealPrimary,
                    focusedLabelColor = TealDark
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number (+251 9... or international)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TealPrimary,
                    focusedLabelColor = TealDark
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address (for booking confirmation)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TealPrimary,
                    focusedLabelColor = TealDark
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = specialRequests,
                onValueChange = { specialRequests = it },
                label = { Text("Special Requests / Airport Pickup Flight #") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TealPrimary,
                    focusedLabelColor = TealDark
                )
            )

            Spacer(modifier = Modifier.height(22.dp))

            // Payment Options Section
            Text(
                text = "Payment Method",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
            Text(
                text = "Choose your preferred Ethiopian payment channel",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Payment Option 1: Telebirr
            PaymentOptionCard(
                isSelected = selectedPayment == PaymentType.TELEBIRR,
                onClick = { selectedPayment = PaymentType.TELEBIRR },
                title = "Telebirr Mobile Pay",
                description = "Instant confirmation via Telebirr mobile wallet (Ethio Telecom)",
                icon = Icons.Default.PhoneAndroid,
                badgeColor = TelebirrBlue
            ) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    Text(
                        text = "Telebirr Registered Phone",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = telebirrPhone,
                        onValueChange = { telebirrPhone = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true,
                        placeholder = { Text("+251 91...") }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "📱 A simulated USSD payment request will be sent to your device.",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Payment Option 2: Bank Transfer
            PaymentOptionCard(
                isSelected = selectedPayment == PaymentType.BANK_TRANSFER,
                onClick = { selectedPayment = PaymentType.BANK_TRANSFER },
                title = "Ethiopian Bank Transfer",
                description = "Commercial Bank of Ethiopia (CBE), Awash, or Abyssinia",
                icon = Icons.Default.AccountBalance,
                badgeColor = TealDark
            ) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    Surface(
                        color = TealSubtle,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Account Details:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TealDark
                            )
                            Text(
                                text = "Bank: Commercial Bank of Ethiopia (CBE)\nAccount: 1000284729184\nAccount Name: StayEthio Hospitality PLC",
                                fontSize = 11.sp,
                                color = NavyPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Enter Transaction Reference / Slip #",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = bankRefNumber,
                        onValueChange = { bankRefNumber = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true,
                        placeholder = { Text("e.g. CBE-TX-928472") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Payment Option 3: Cash on Arrival
            PaymentOptionCard(
                isSelected = selectedPayment == PaymentType.CASH_ON_ARRIVAL,
                onClick = { selectedPayment = PaymentType.CASH_ON_ARRIVAL },
                title = "Cash on Arrival (Pay at Hotel)",
                description = "Pay directly at hotel reception in ETB or USD upon check-in",
                icon = Icons.Default.Paid,
                badgeColor = EmeraldGreen
            ) {
                Text(
                    text = "✓ Reservation is immediately held. Pay front desk during check-in in cash or card.",
                    fontSize = 11.sp,
                    color = EmeraldGreen,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Price Breakdown Table
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceNeutral)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Price Breakdown",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${StayEthioRepository.formatPrice(room.pricePerNightEtb)} × $nights nights",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = StayEthioRepository.formatPrice(subtotal),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NavyPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Ethiopian VAT & Service Tax (15%)",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = StayEthioRepository.formatPrice(vatTaxes),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NavyPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BorderNeutral))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Total Payable",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                        Text(
                            text = StayEthioRepository.formatPrice(total),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TealDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Prototype Disclosure Notice (as required by prompt guidelines)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = SurfaceNeutral,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderNeutral)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Prototype mode: simulated payments for testing & demonstration.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Confirm Reservation Button
            Button(
                onClick = {
                    isProcessing = true
                    val newBooking = StayEthioRepository.createBooking(
                        hotel = hotel,
                        room = room,
                        checkIn = StayEthioRepository.searchCriteria.checkInDate,
                        checkOut = StayEthioRepository.searchCriteria.checkOutDate,
                        nights = nights,
                        guests = StayEthioRepository.searchCriteria.guestCount,
                        fullName = fullName,
                        phone = phone,
                        email = email,
                        requests = specialRequests,
                        paymentType = selectedPayment,
                        telebirrPhone = if (selectedPayment == PaymentType.TELEBIRR) telebirrPhone else null,
                        bankRef = if (selectedPayment == PaymentType.BANK_TRANSFER) bankRefNumber else null
                    )
                    isProcessing = false
                    onBookingSuccess(newBooking)
                },
                enabled = !isProcessing && fullName.isNotBlank() && phone.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealPrimary,
                    contentColor = Color.White
                )
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Confirm Booking (${StayEthioRepository.formatPrice(total)})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
private fun PaymentOptionCard(
    isSelected: Boolean,
    onClick: () -> Unit,
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeColor: Color,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) TealPrimary else BorderNeutral,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) TealSubtle.copy(alpha = 0.4f) else Color.White
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = isSelected,
                    onClick = onClick,
                    colors = RadioButtonDefaults.colors(selectedColor = TealPrimary)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = description,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            if (isSelected) {
                content()
            }
        }
    }
}
