package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// StayEthio Signature Brand Colors: White, Dark Navy-Blue, Teal Accents
val NavyDark = Color(0xFF0A1128)        // Deep navy
val NavyPrimary = Color(0xFF0F172A)     // Dark navy-blue header & text
val NavySurface = Color(0xFF1E293B)     // Navy card / secondary
val NavyLight = Color(0xFF334155)       // Muted slate text

val TealPrimary = Color(0xFF0D9488)     // Primary Teal accent
val TealDark = Color(0xFF0F766E)        // Dark teal
val TealLight = Color(0xFF14B8A6)       // Bright teal
val TealSubtle = Color(0xFFF0FDFA)      // Very soft teal background
val TealBorder = Color(0xFF99F6E4)      // Soft teal border

// Backgrounds & Neutrals
val AppBackground = Color(0xFFFFFFFF)   // Pure white background
val SurfaceNeutral = Color(0xFFF8FAFC)  // Light crisp neutral surface
val SurfaceCard = Color(0xFFFFFFFF)     // Card white
val BorderNeutral = Color(0xFFE2E8F0)   // Subtle hairline border
val TextPrimary = Color(0xFF0F172A)     // Crisp dark slate
val TextSecondary = Color(0xFF64748B)   // Muted slate
val TextMuted = Color(0xFF94A3B8)       // Tertiary subtle

// Status & Indicators
val AmberStar = Color(0xFFF59E0B)       // Star ratings
val EmeraldGreen = Color(0xFF10B981)    // Confirmed / active
val RoseRed = Color(0xFFEF4444)         // Cancelled / alert
val TelebirrBlue = Color(0xFF0072CE)    // Telebirr brand color
val CbePurple = Color(0xFF7E22CE)       // Commercial Bank of Ethiopia tone

