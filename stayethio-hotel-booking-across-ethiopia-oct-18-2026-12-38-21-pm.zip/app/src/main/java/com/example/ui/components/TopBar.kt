package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookOnline
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StayEthioRepository
import com.example.model.UserRole
import com.example.ui.theme.BorderNeutral
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SurfaceNeutral
import com.example.ui.theme.TealDark
import com.example.ui.theme.TealLight
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.TealSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TopBar(
    onNavigateHome: () -> Unit,
    onNavigateBookings: () -> Unit,
    currentScreen: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Zone 1: Main Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand wordmark
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onNavigateHome() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NavyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SE",
                            color = TealLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Stay",
                                color = NavyPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "Ethio",
                                color = TealPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp,
                                letterSpacing = (-0.5).sp
                            )
                        }
                        Text(
                            text = "Ethiopian Hotel Booking",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Currency Toggle & My Bookings Quick Access
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Currency Switcher
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = SurfaceNeutral,
                        modifier = Modifier.clickable {
                            StayEthioRepository.isUsdCurrency = !StayEthioRepository.isUsdCurrency
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CurrencyExchange,
                                contentDescription = "Currency",
                                tint = TealDark,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (StayEthioRepository.isUsdCurrency) "USD ($)" else "ETB (ብር)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                        }
                    }

                    // My Bookings Shortcut
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (currentScreen == "my_bookings") TealPrimary else TealSubtle,
                        modifier = Modifier.clickable { onNavigateBookings() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            BadgedBox(
                                badge = {
                                    if (StayEthioRepository.bookings.isNotEmpty()) {
                                        Badge(
                                            containerColor = TealDark,
                                            contentColor = Color.White
                                        ) {
                                            Text(
                                                text = "${StayEthioRepository.bookings.size}",
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BookOnline,
                                    contentDescription = "Bookings",
                                    tint = if (currentScreen == "my_bookings") Color.White else TealDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Bookings",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (currentScreen == "my_bookings") Color.White else NavyPrimary
                            )
                        }
                    }
                }
            }

            // Role Switcher Strip (Guest, Hotel Owner, Admin)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceNeutral)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Mode:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RoleChip(
                        title = "Traveler",
                        icon = Icons.Default.Person,
                        isSelected = StayEthioRepository.currentRole == UserRole.GUEST,
                        onClick = { StayEthioRepository.currentRole = UserRole.GUEST }
                    )
                    RoleChip(
                        title = "Hotel Partner",
                        icon = Icons.Default.Business,
                        isSelected = StayEthioRepository.currentRole == UserRole.HOTEL_OWNER,
                        onClick = { StayEthioRepository.currentRole = UserRole.HOTEL_OWNER }
                    )
                    RoleChip(
                        title = "Admin",
                        icon = Icons.Default.Security,
                        isSelected = StayEthioRepository.currentRole == UserRole.ADMIN,
                        onClick = { StayEthioRepository.currentRole = UserRole.ADMIN }
                    )
                }
            }
        }
    }
}

@Composable
private fun RoleChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) NavyPrimary else Color.White,
        shadowElevation = if (isSelected) 1.dp else 0.dp,
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) TealLight else TextSecondary,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextPrimary
            )
        }
    }
}
