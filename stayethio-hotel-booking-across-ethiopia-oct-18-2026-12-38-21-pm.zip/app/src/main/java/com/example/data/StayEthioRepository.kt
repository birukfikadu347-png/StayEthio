package com.example.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.R
import com.example.model.Booking
import com.example.model.BookingStatus
import com.example.model.Hotel
import com.example.model.PaymentType
import com.example.model.Review
import com.example.model.RoomType
import com.example.model.SearchCriteria
import com.example.model.UserRole
import java.util.UUID

object StayEthioRepository {
    // Current active role
    var currentRole by mutableStateOf(UserRole.GUEST)
    
    // Currency toggle: ETB (default) or USD
    var isUsdCurrency by mutableStateOf(false)
    val etbToUsdRate = 122.5 // Approximate market conversion

    fun formatPrice(amountEtb: Double): String {
        return if (isUsdCurrency) {
            val usd = amountEtb / etbToUsdRate
            String.format("$%.0f USD", usd)
        } else {
            String.format("%,.0f ETB", amountEtb)
        }
    }

    // Available Ethiopian Cities
    val ethiopianCities = listOf(
        "All Cities",
        "Addis Ababa",
        "Bishoftu",
        "Lalibela",
        "Bahir Dar",
        "Hawassa",
        "Gondar",
        "Arba Minch"
    )

    // Room types template
    private fun createDefaultRooms(basePrice: Double): List<RoomType> {
        return listOf(
            RoomType(
                id = "room_deluxe_${UUID.randomUUID().toString().take(6)}",
                name = "Deluxe King Room",
                description = "Spacious room with king bed, Ethiopian traditional cotton accents, panoramic views, en-suite marble bath and dedicated workspace.",
                bedType = "1 King Bed",
                maxGuests = 2,
                pricePerNightEtb = basePrice,
                sizeSqMeters = 38,
                amenities = listOf("High-speed WiFi", "Air Conditioning", "Espresso & Buna Bar", "City/Nature Balcony", "Rain Shower"),
                imageRes = R.drawable.hotel_room
            ),
            RoomType(
                id = "room_exec_${UUID.randomUUID().toString().take(6)}",
                name = "Executive Panoramic Suite",
                description = "Lavish suite with separate lounge area, executive lounge access, complimentary laundry, and premium scenic vistas.",
                bedType = "1 Extra-Large King Bed",
                maxGuests = 3,
                pricePerNightEtb = basePrice * 1.55,
                sizeSqMeters = 58,
                amenities = listOf("Executive Lounge Access", "Free Bole Airport Transfer", "Bespoke Ethiopian Coffee Service", "Deep Soaking Tub", "Smart TV 65\""),
                imageRes = R.drawable.hotel_room
            ),
            RoomType(
                id = "room_presidential_${UUID.randomUUID().toString().take(6)}",
                name = "Presidential Heritage Suite",
                description = "Masterpiece suite offering handcrafted timber furniture, VIP dining room, dedicated butler on call, and highest floor panoramas.",
                bedType = "2 King Bedrooms",
                maxGuests = 4,
                pricePerNightEtb = basePrice * 2.8,
                sizeSqMeters = 110,
                amenities = listOf("Private Butler", "Complimentary Minibar", "VIP Airport Fast-Track", "Jacuzzi", "Panoramic Terrace"),
                imageRes = R.drawable.hotel_hero
            )
        )
    }

    // In-memory list of hotels
    val hotels = mutableStateListOf<Hotel>(
        Hotel(
            id = "hotel_skylight",
            name = "Addis Skylight Hotel",
            city = "Addis Ababa",
            subCityOrArea = "Bole",
            fullAddress = "Airport Road, Bole Sub-City, Addis Ababa, Ethiopia",
            starRating = 5,
            reviewScore = 4.9,
            reviewCount = 542,
            startingPriceEtb = 11500.0,
            mainImageRes = R.drawable.hotel_skylight,
            galleryImages = listOf(R.drawable.hotel_skylight, R.drawable.hotel_room, R.drawable.hotel_hero),
            description = "Africa's grandest hospitality icon, located merely 5 minutes from Addis Ababa Bole International Airport. Features world-class dining, multiple banquet halls, an expansive heated outdoor pool, an authentic Ethiopian cultural coffee lounge, and 1,024 opulent rooms.",
            highlights = listOf("5 mins to Bole Airport", "Heated Pool & Luxury Spa", "Authentic Ethiopian Buna Ceremony", "24/7 Free Airport Shuttle"),
            amenities = listOf("Free Airport Shuttle", "Swimming Pool", "High-speed WiFi", "Fitness Center", "Spa & Sauna", "Buna Coffee Bar", "Fine Dining Restaurants", "Currency Exchange"),
            rooms = createDefaultRooms(11500.0),
            isFeatured = true,
            isVerified = true,
            ownerId = "owner_skylight",
            distanceToAirportKm = 0.8
        ),
        Hotel(
            id = "hotel_kuriftu",
            name = "Kuriftu Resort & Spa Bishoftu",
            city = "Bishoftu",
            subCityOrArea = "Lake Babogaya",
            fullAddress = "Crater Lake Way, Bishoftu (Debre Zeyit), Oromia, Ethiopia",
            starRating = 5,
            reviewScore = 4.85,
            reviewCount = 384,
            startingPriceEtb = 9800.0,
            mainImageRes = R.drawable.hotel_kuriftu,
            galleryImages = listOf(R.drawable.hotel_kuriftu, R.drawable.hotel_room, R.drawable.hotel_hero),
            description = "Nestled alongside the tranquil crater waters of Lake Babogaya in Bishoftu, Kuriftu Resort blends handcrafted Ethiopian woodcraft and traditional thatched cabanas with luxurious modern wellness spas, water cinema, and lakeside organic dining.",
            highlights = listOf("Lakeside Crater Cabanas", "Open-air Water Cinema", "Signature Swedish & Herbal Spa", "Sunset Lake Kayaking"),
            amenities = listOf("Lake View Balconies", "Full Service Spa", "Free Breakfast Buffet", "Outdoor Swimming Pool", "Kayaking & Boat Rentals", "High-speed WiFi", "Organic Ethiopian Cuisine"),
            rooms = createDefaultRooms(9800.0),
            isFeatured = true,
            isVerified = true,
            ownerId = "owner_kuriftu",
            distanceToAirportKm = 48.0
        ),
        Hotel(
            id = "hotel_lalibela",
            name = "Lalibela Rock Valley Lodge",
            city = "Lalibela",
            subCityOrArea = "Highland Ridge",
            fullAddress = "Monolithic Sanctuary Road, Lalibela, Amhara, Ethiopia",
            starRating = 5,
            reviewScore = 4.95,
            reviewCount = 219,
            startingPriceEtb = 8200.0,
            mainImageRes = R.drawable.hotel_lalibela,
            galleryImages = listOf(R.drawable.hotel_lalibela, R.drawable.hotel_room, R.drawable.hotel_hero),
            description = "Perched dramatically on the cliff edge overlooking the awe-inspiring canyons of Lalibela, this boutique lodge offers front-row seats to UNESCO monolithic churches, traditional stone architecture, and unforgettable highland sunsets.",
            highlights = listOf("UNESCO Rock Churches 10 min", "Cliffside Valley Views", "Daily Evening Buna Ceremony", "Guided Cultural Excursions"),
            amenities = listOf("Highland View Terrace", "Free Airport Pick-up", "Organic Mountain Breakfast", "High-speed WiFi", "Cultural Music Nights", "Trekking Gear Rental"),
            rooms = createDefaultRooms(8200.0),
            isFeatured = true,
            isVerified = true,
            ownerId = "owner_lalibela",
            distanceToAirportKm = 22.0
        ),
        Hotel(
            id = "hotel_haile_grand",
            name = "Haile Grand Addis Ababa",
            city = "Addis Ababa",
            subCityOrArea = "Yeka CMC",
            fullAddress = "CMC Road, Yeka Sub-City, Addis Ababa, Ethiopia",
            starRating = 5,
            reviewScore = 4.8,
            reviewCount = 310,
            startingPriceEtb = 10200.0,
            mainImageRes = R.drawable.hotel_hero,
            galleryImages = listOf(R.drawable.hotel_hero, R.drawable.hotel_skylight, R.drawable.hotel_room),
            description = "Founded by legendary Olympic champion Haile Gebrselassie, Haile Grand exemplifies athletic vigor and warm Ethiopian hospitality. Highlights include world-class fitness grounds, lush botanical gardens, and authentic Ethiopian dining.",
            highlights = listOf("Olympic Champion Legacy", "Championship Health Club", "Traditional Mesob Dining", "Quiet CMC Green Zone"),
            amenities = listOf("Heated Indoor/Outdoor Pool", "Fitness & Recovery Club", "Free Airport Shuttle", "High-speed WiFi", "Mesob Cultural Restaurant", "Conference Center"),
            rooms = createDefaultRooms(10200.0),
            isFeatured = true,
            isVerified = true,
            ownerId = "owner_haile",
            distanceToAirportKm = 7.5
        ),
        Hotel(
            id = "hotel_avanti_blue_nile",
            name = "Avanti Blue Nile Resort",
            city = "Bahir Dar",
            subCityOrArea = "Lake Tana Shore",
            fullAddress = "Lakeside Boulevard, Bahir Dar, Amhara, Ethiopia",
            starRating = 4,
            reviewScore = 4.7,
            reviewCount = 186,
            startingPriceEtb = 7400.0,
            mainImageRes = R.drawable.hotel_kuriftu,
            galleryImages = listOf(R.drawable.hotel_kuriftu, R.drawable.hotel_room),
            description = "A peaceful waterfront oasis on the shores of Lake Tana, the source of the Blue Nile. Walk straight to private boat excursions exploring centuries-old island monasteries and enjoy tropical gardens by the water.",
            highlights = listOf("Direct Lake Tana Boat Dock", "Island Monasteries Tours", "Tropical Garden Cabanas", "Blue Nile Sunset Bar"),
            amenities = listOf("Lakefront Swimming Pool", "Boat Dock", "Free Breakfast", "Tropical Gardens", "High-speed WiFi", "Poolside Grill"),
            rooms = createDefaultRooms(7400.0),
            isFeatured = false,
            isVerified = true,
            ownerId = "owner_avanti",
            distanceToAirportKm = 9.0
        ),
        Hotel(
            id = "hotel_lewi_hawassa",
            name = "Lewi Resort & Spa Hawassa",
            city = "Hawassa",
            subCityOrArea = "Lake Hawassa Front",
            fullAddress = "Lakeside Avenue, Hawassa, Sidama, Ethiopia",
            starRating = 4,
            reviewScore = 4.75,
            reviewCount = 152,
            startingPriceEtb = 6900.0,
            mainImageRes = R.drawable.hotel_lalibela,
            galleryImages = listOf(R.drawable.hotel_lalibela, R.drawable.hotel_room),
            description = "Enjoy pristine lakeside serenity in the vibrant city of Hawassa. Watch playful colobus monkeys in the lush trees, take evening boat rides to see hippos, and savor freshly caught Nile tilapia.",
            highlights = listOf("Lake Hawassa Promenade", "Fresh Fish Grill", "Wildlife & Bird Sanctuary", "Family Aquatic Fun"),
            amenities = listOf("Lake View Suites", "Outdoor Pool", "Sauna & Steam", "Free Breakfast", "High-speed WiFi", "Children's Playground"),
            rooms = createDefaultRooms(6900.0),
            isFeatured = false,
            isVerified = true,
            ownerId = "owner_lewi",
            distanceToAirportKm = 14.0
        )
    )

    // In-memory bookings list
    val bookings = mutableStateListOf<Booking>(
        Booking(
            id = "bk_001",
            referenceCode = "ETH-84920",
            hotelId = "hotel_skylight",
            hotelName = "Addis Skylight Hotel",
            hotelCity = "Addis Ababa",
            hotelImageRes = R.drawable.hotel_skylight,
            roomTypeName = "Deluxe King Room",
            checkInDate = "Oct 24, 2026",
            checkOutDate = "Oct 27, 2026",
            nightsCount = 3,
            guestCount = 2,
            guestFullName = "Yakin Yohannes",
            guestPhone = "+251 91 123 4567",
            guestEmail = "yakin@example.com",
            specialRequests = "High floor room facing the fountain, early check-in if available.",
            subtotalEtb = 34500.0,
            taxesEtb = 5175.0,
            totalAmountEtb = 39675.0,
            paymentType = PaymentType.TELEBIRR,
            paymentStatus = "Paid (Verified)",
            bookingStatus = BookingStatus.CONFIRMED,
            createdAt = "Oct 18, 2026",
            telebirrPhone = "+251 91 123 4567"
        ),
        Booking(
            id = "bk_002",
            referenceCode = "ETH-61205",
            hotelId = "hotel_kuriftu",
            hotelName = "Kuriftu Resort & Spa Bishoftu",
            hotelCity = "Bishoftu",
            hotelImageRes = R.drawable.hotel_kuriftu,
            roomTypeName = "Executive Panoramic Suite",
            checkInDate = "Nov 12, 2026",
            checkOutDate = "Nov 14, 2026",
            nightsCount = 2,
            guestCount = 2,
            guestFullName = "Almaz Bekele",
            guestPhone = "+251 92 876 5432",
            guestEmail = "almaz.b@example.com",
            specialRequests = "Anniversary couple setup with traditional flower petals.",
            subtotalEtb = 30380.0,
            taxesEtb = 4557.0,
            totalAmountEtb = 34937.0,
            paymentType = PaymentType.BANK_TRANSFER,
            paymentStatus = "Paid (CBE Transfer)",
            bookingStatus = BookingStatus.CONFIRMED,
            createdAt = "Oct 15, 2026",
            bankTransactionRef = "CBE-TX-998241772"
        ),
        Booking(
            id = "bk_003",
            referenceCode = "ETH-19342",
            hotelId = "hotel_lalibela",
            hotelName = "Lalibela Rock Valley Lodge",
            hotelCity = "Lalibela",
            hotelImageRes = R.drawable.hotel_lalibela,
            roomTypeName = "Deluxe King Room",
            checkInDate = "Dec 05, 2026",
            checkOutDate = "Dec 08, 2026",
            nightsCount = 3,
            guestCount = 1,
            guestFullName = "Marcus Vance",
            guestPhone = "+1 415 555 0192",
            guestEmail = "marcus.v@example.org",
            specialRequests = "English-speaking church tour guide requested upon arrival.",
            subtotalEtb = 24600.0,
            taxesEtb = 3690.0,
            totalAmountEtb = 28290.0,
            paymentType = PaymentType.CASH_ON_ARRIVAL,
            paymentStatus = "Due on Arrival (Guaranteed)",
            bookingStatus = BookingStatus.CONFIRMED,
            createdAt = "Oct 12, 2026"
        )
    )

    // Current search criteria
    var searchCriteria by mutableStateOf(SearchCriteria())

    // Reviews database
    val sampleReviews = listOf(
        Review(
            id = "rev_1",
            authorName = "Hanna Tadesse",
            cityOrCountry = "Addis Ababa",
            rating = 5.0,
            date = "2 days ago",
            comment = "Exceptional hospitality! The traditional Ethiopian coffee ceremony in the afternoon was magical, and the airport shuttle arrived in less than 5 minutes. The room was spotless and bed extremely comfortable."
        ),
        Review(
            id = "rev_2",
            authorName = "David Miller",
            cityOrCountry = "London, UK",
            rating = 5.0,
            date = "1 week ago",
            comment = "One of the best stays in East Africa. The view from our balcony over the mountain canyon was breathtaking. Paying seamlessly via Telebirr simulation and local bank card worked like a charm."
        ),
        Review(
            id = "rev_3",
            authorName = "Selamawit Kebede",
            cityOrCountry = "Hawassa",
            rating = 4.8,
            date = "2 weeks ago",
            comment = "Peaceful retreat with authentic decor and warm staff. Breakfast buffet had rich Ethiopian dishes (chechebsa, ful, fresh injera) as well as continental pastries."
        )
    )

    // Actions
    fun createBooking(
        hotel: Hotel,
        room: RoomType,
        checkIn: String,
        checkOut: String,
        nights: Int,
        guests: Int,
        fullName: String,
        phone: String,
        email: String,
        requests: String,
        paymentType: PaymentType,
        telebirrPhone: String? = null,
        bankRef: String? = null
    ): Booking {
        val subtotal = room.pricePerNightEtb * nights
        val taxes = subtotal * 0.15 // 15% Ethiopian VAT
        val total = subtotal + taxes

        val paymentStatus = when (paymentType) {
            PaymentType.TELEBIRR -> "Paid (Telebirr Verified)"
            PaymentType.BANK_TRANSFER -> "Pending Bank Slip Audit"
            PaymentType.CASH_ON_ARRIVAL -> "Due on Arrival"
        }

        val refCode = "ETH-${(10000..99999).random()}"

        val newBooking = Booking(
            id = "bk_${UUID.randomUUID().toString().take(8)}",
            referenceCode = refCode,
            hotelId = hotel.id,
            hotelName = hotel.name,
            hotelCity = hotel.city,
            hotelImageRes = hotel.mainImageRes,
            roomTypeName = room.name,
            checkInDate = checkIn,
            checkOutDate = checkOut,
            nightsCount = nights,
            guestCount = guests,
            guestFullName = fullName,
            guestPhone = phone,
            guestEmail = email,
            specialRequests = requests,
            subtotalEtb = subtotal,
            taxesEtb = taxes,
            totalAmountEtb = total,
            paymentType = paymentType,
            paymentStatus = paymentStatus,
            bookingStatus = BookingStatus.CONFIRMED,
            createdAt = "Today",
            bankTransactionRef = bankRef,
            telebirrPhone = telebirrPhone
        )

        bookings.add(0, newBooking)
        return newBooking
    }

    fun cancelBooking(bookingId: String): Boolean {
        val index = bookings.indexOfFirst { it.id == bookingId }
        if (index != -1) {
            val current = bookings[index]
            bookings[index] = current.copy(bookingStatus = BookingStatus.CANCELLED)
            return true
        }
        return false
    }

    fun updateBookingStatus(bookingId: String, newStatus: BookingStatus) {
        val index = bookings.indexOfFirst { it.id == bookingId }
        if (index != -1) {
            bookings[index] = bookings[index].copy(bookingStatus = newStatus)
        }
    }

    fun addNewHotel(
        name: String,
        city: String,
        subCity: String,
        address: String,
        priceEtb: Double,
        description: String,
        amenities: List<String>,
        highlights: List<String>
    ): Hotel {
        val newHotel = Hotel(
            id = "hotel_${UUID.randomUUID().toString().take(8)}",
            name = name,
            city = city,
            subCityOrArea = subCity,
            fullAddress = address,
            starRating = 4,
            reviewScore = 5.0,
            reviewCount = 1,
            startingPriceEtb = priceEtb,
            mainImageRes = R.drawable.hotel_hero,
            galleryImages = listOf(R.drawable.hotel_hero, R.drawable.hotel_room),
            description = description,
            highlights = highlights.ifEmpty { listOf("Warm Ethiopian Hospitality", "Central Location") },
            amenities = amenities.ifEmpty { listOf("High-speed WiFi", "Room Service", "Breakfast Included") },
            rooms = createDefaultRooms(priceEtb),
            isFeatured = false,
            isVerified = false, // Pending admin approval
            ownerId = "partner_current"
        )
        hotels.add(0, newHotel)
        return newHotel
    }

    fun toggleHotelVerification(hotelId: String) {
        val index = hotels.indexOfFirst { it.id == hotelId }
        if (index != -1) {
            val h = hotels[index]
            hotels[index] = h.copy(isVerified = !h.isVerified)
        }
    }
}
