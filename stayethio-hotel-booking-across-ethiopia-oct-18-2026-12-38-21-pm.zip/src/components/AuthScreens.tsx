import React, { useState, useEffect, useRef } from 'react';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  User,
  Phone,
  ArrowLeft,
  CheckCircle2,
  Building,
  KeyRound,
  AlertCircle,
  Clock,
  RefreshCw,
  Info,
  ShieldCheck,
  Sparkles,
  MapPin,
  ChevronRight
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';

interface AuthScreensProps {
  initialMode?: 'login' | 'signup' | 'forgot_password';
  onLoginSuccess: (user: UserProfile) => void;
  onExploreAsGuest: () => void;
}

type LoginTab = 'phone' | 'email';
type OtpPurpose = 'phone_login' | 'signup_verification';

export default function AuthScreens({
  initialMode = 'login',
  onLoginSuccess,
  onExploreAsGuest
}: AuthScreensProps) {
  const [mode, setMode] = useState<'login' | 'signup' | 'otp' | 'forgot_password'>(initialMode);
  const [loginTab, setLoginTab] = useState<LoginTab>('phone');

  // Phone Login State
  const [phoneLoginNumber, setPhoneLoginNumber] = useState('');
  const [phoneLoginError, setPhoneLoginError] = useState('');

  // Email Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loginError, setLoginError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sign Up State
  const [signupRole, setSignupRole] = useState<'guest' | 'owner'>('guest');
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [signupError, setSignupError] = useState('');

  // Pending signup user for OTP step
  const [pendingUser, setPendingUser] = useState<{
    name: string;
    email: string;
    phone: string;
    role: 'guest' | 'owner';
  } | null>(null);

  // OTP State
  const [otpTarget, setOtpTarget] = useState('+251 91 123 4567');
  const [otpPurpose, setOtpPurpose] = useState<OtpPurpose>('phone_login');
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpError, setOtpError] = useState('');
  const [otpSuccessMessage, setOtpSuccessMessage] = useState('');
  const [expirySeconds, setExpirySeconds] = useState(300); // 5 minutes = 300 seconds
  const [resendCooldown, setResendCooldown] = useState(60); // 60 seconds cooldown
  const [isOtpVerifying, setIsOtpVerifying] = useState(false);
  const otpInputsRef = useRef<(HTMLInputElement | null)[]>([]);

  // Forgot Password State
  const [forgotRecoveryMethod, setForgotRecoveryMethod] = useState<'email' | 'phone'>('email');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotPhone, setForgotPhone] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const [forgotError, setForgotError] = useState('');

  // Google Sign In Modal State
  const [showGoogleInfoModal, setShowGoogleInfoModal] = useState(false);

  // OTP Expiry & Resend Timers
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (mode === 'otp') {
      timer = setInterval(() => {
        setExpirySeconds((prev) => (prev > 0 ? prev - 1 : 0));
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [mode]);

  // Format seconds to mm:ss
  const formatTimer = (totalSeconds: number) => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  // Helper to normalize phone number input (removes non-digits)
  const sanitizePhone = (val: string) => {
    return val.replace(/\D/g, '').slice(0, 9);
  };

  // Helper to format phone for display (e.g. 91 123 4567)
  const formatPhoneDisplay = (digits: string) => {
    if (digits.length <= 2) return digits;
    if (digits.length <= 5) return `${digits.slice(0, 2)} ${digits.slice(2)}`;
    return `${digits.slice(0, 2)} ${digits.slice(2, 5)} ${digits.slice(5, 9)}`;
  };

  // Trigger OTP for Phone Login
  const handleInitiatePhoneLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneLoginError('');

    const clean = sanitizePhone(phoneLoginNumber);
    if (clean.length !== 9) {
      setPhoneLoginError('Please enter a valid 9-digit Ethiopian mobile number (e.g. 91 123 4567 or 71 234 5678).');
      return;
    }

    if (!clean.startsWith('9') && !clean.startsWith('7')) {
      setPhoneLoginError('Ethiopian mobile numbers start with 9 (Ethio Telecom) or 7 (Safaricom Ethiopia).');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setOtpTarget(`+251 ${formatPhoneDisplay(clean)}`);
      setOtpPurpose('phone_login');
      setOtpDigits(['', '', '', '', '', '']);
      setOtpError('');
      setOtpSuccessMessage('6-digit SMS verification code has been dispatched.');
      setExpirySeconds(300); // 5 minutes
      setResendCooldown(60); // 60 seconds
      setMode('otp');
    }, 600);
  };

  // Submit Email Login Form
  const submitEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!loginEmail.trim() || !loginEmail.includes('@')) {
      setLoginError('Please enter a valid email address.');
      return;
    }

    if (!loginPassword) {
      setLoginError('Please enter your account password.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);

      const emailLower = loginEmail.toLowerCase().trim();
      let role: UserRole = 'guest';
      let name = 'Guest Traveler';

      if (emailLower.includes('admin@stayethio.com')) {
        role = 'admin';
        name = 'System Administrator';
      } else if (emailLower.includes('partner') || emailLower.includes('owner') || emailLower.includes('hotel')) {
        role = 'owner';
        name = 'Hotel Partner';
      } else {
        const usernamePart = loginEmail.split('@')[0];
        name = usernamePart
          ? usernamePart
              .replace(/[._-]/g, ' ')
              .split(' ')
              .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
              .join(' ')
          : 'Yakin Yohannes';
      }

      const user: UserProfile = {
        id: `usr_${Date.now()}`,
        name,
        email: loginEmail,
        phone: '+251 91 123 4567',
        role,
        isLoggedIn: true
      };

      onLoginSuccess(user);
    }, 650);
  };

  // Submit Sign Up Form (Triggers OTP verification before account activation)
  const submitSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError('');

    if (!signupName.trim()) {
      setSignupError('Please enter your full name.');
      return;
    }

    const cleanPhone = sanitizePhone(signupPhone);
    if (cleanPhone.length !== 9) {
      setSignupError('Please enter a valid 9-digit Ethiopian phone number (e.g. 91 123 4567).');
      return;
    }

    if (!cleanPhone.startsWith('9') && !cleanPhone.startsWith('7')) {
      setSignupError('Ethiopian mobile numbers start with 9 (Ethio Telecom) or 7 (Safaricom Ethiopia).');
      return;
    }

    if (!signupEmail.trim() || !signupEmail.includes('@') || !signupEmail.includes('.')) {
      setSignupError('Please enter a valid email address.');
      return;
    }

    if (signupPassword.length < 6) {
      setSignupError('Password must contain at least 6 characters.');
      return;
    }

    if (signupPassword !== signupConfirmPassword) {
      setSignupError('Passwords do not match. Please re-enter.');
      return;
    }

    if (!agreeTerms) {
      setSignupError('You must agree to the Terms of Service & Privacy Policy.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);

      // Save pending user
      setPendingUser({
        name: signupName.trim(),
        email: signupEmail.trim(),
        phone: `+251 ${formatPhoneDisplay(cleanPhone)}`,
        role: signupRole
      });

      // Move to OTP verification before activating the phone & account
      setOtpTarget(`+251 ${formatPhoneDisplay(cleanPhone)}`);
      setOtpPurpose('signup_verification');
      setOtpDigits(['', '', '', '', '', '']);
      setOtpError('');
      setOtpSuccessMessage('Verification code sent to verify and activate your phone number.');
      setExpirySeconds(300); // 5 minutes
      setResendCooldown(60); // 60 seconds
      setMode('otp');
    }, 600);
  };

  // Handle OTP digit changes
  const handleOtpDigitChange = (index: number, val: string) => {
    const cleaned = val.replace(/\D/g, '');
    const newDigits = [...otpDigits];

    if (cleaned.length > 1) {
      // User pasted multiple characters
      const pasted = cleaned.slice(0, 6).split('');
      for (let i = 0; i < 6; i++) {
        newDigits[i] = pasted[i] || '';
      }
      setOtpDigits(newDigits);
      const nextEmpty = newDigits.findIndex((d) => d === '');
      const focusIndex = nextEmpty === -1 ? 5 : nextEmpty;
      otpInputsRef.current[focusIndex]?.focus();
      return;
    }

    newDigits[index] = cleaned;
    setOtpDigits(newDigits);

    // Auto-advance to next input
    if (cleaned && index < 5) {
      otpInputsRef.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputsRef.current[index - 1]?.focus();
    }
  };

  const handleResendOtp = () => {
    if (resendCooldown > 0) return;
    setOtpDigits(['', '', '', '', '', '']);
    setOtpError('');
    setOtpSuccessMessage('A fresh 6-digit verification code has been dispatched.');
    setExpirySeconds(300);
    setResendCooldown(60);
    otpInputsRef.current[0]?.focus();
  };

  // Verify OTP Code
  const submitVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpError('');

    const fullCode = otpDigits.join('');
    if (fullCode.length !== 6) {
      setOtpError('Please enter all 6 digits of the verification code.');
      return;
    }

    if (expirySeconds <= 0) {
      setOtpError('Verification code has expired. Please tap "Resend Code" to request a new one.');
      return;
    }

    setIsOtpVerifying(true);
    setTimeout(() => {
      setIsOtpVerifying(false);

      if (otpPurpose === 'signup_verification' && pendingUser) {
        // Activate new user account
        const user: UserProfile = {
          id: `usr_${Date.now()}`,
          name: pendingUser.name,
          email: pendingUser.email,
          phone: pendingUser.phone,
          role: pendingUser.role,
          isLoggedIn: true
        };
        onLoginSuccess(user);
      } else {
        // Phone login user
        const user: UserProfile = {
          id: `usr_${Date.now()}`,
          name: 'Verified Traveler',
          email: `guest_${otpTarget.replace(/\D/g, '').slice(-4)}@stayethio.com`,
          phone: otpTarget,
          role: 'guest',
          isLoggedIn: true
        };
        onLoginSuccess(user);
      }
    }, 700);
  };

  // Submit Forgot Password
  const submitForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');

    if (forgotRecoveryMethod === 'email') {
      if (!forgotEmail.trim() || !forgotEmail.includes('@') || !forgotEmail.includes('.')) {
        setForgotError('Please enter a valid registered email address.');
        return;
      }
    } else {
      const cleanPhone = sanitizePhone(forgotPhone);
      if (cleanPhone.length !== 9) {
        setForgotError('Please enter a valid 9-digit Ethiopian mobile number.');
        return;
      }
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setResetSent(true);
    }, 600);
  };

  const handleGoogleSignInClick = () => {
    setShowGoogleInfoModal(true);
  };

  const handleContinueWithGoogleProfile = () => {
    setShowGoogleInfoModal(false);
    const googleUser: UserProfile = {
      id: `google_${Date.now()}`,
      name: 'Yakin Yohannes',
      email: 'yakinyk8@gmail.com',
      phone: '+251 91 123 4567',
      role: 'guest',
      isLoggedIn: true
    };
    onLoginSuccess(googleUser);
  };

  return (
    <div className="min-h-screen bg-slate-900 sm:bg-slate-100 flex flex-col justify-center sm:py-12 sm:px-4 lg:px-8">
      {/* Container - Edge-to-edge on mobile, sleek centered phone card on desktop */}
      <div className="w-full sm:max-w-md mx-auto bg-white sm:rounded-3xl shadow-2xl sm:border sm:border-slate-200/80 overflow-hidden flex flex-col min-h-screen sm:min-h-0">
        
        {/* ============================================================== */}
        {/* ================ HOSPITALITY HERO HEADER BANNER ============= */}
        {/* ============================================================== */}
        <div className="relative h-56 sm:h-60 w-full overflow-hidden shrink-0 bg-slate-950">
          {/* Authentic Hospitality Photo */}
          <img
            src="/images/hotel_hero.jpg"
            alt="StayEthio Luxury Hospitality"
            className="w-full h-full object-cover object-center scale-105 filter brightness-90 contrast-105"
          />

          {/* Luxury Gradient Overlays: Navy/Teal vignette */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-transparent to-slate-950/40" />

          {/* Top Floating Bar: Explore as Guest button */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-950/60 backdrop-blur-md border border-white/10 text-white shadow-sm">
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
              <span className="text-[11px] font-semibold tracking-wide text-slate-200">Ethiopian Hospitality</span>
            </div>

            <button
              type="button"
              onClick={onExploreAsGuest}
              className="text-xs font-semibold text-white/90 hover:text-white px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/20 transition-all cursor-pointer flex items-center gap-1 active:scale-95"
            >
              <span>Explore as Guest</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Brand Identity & Welcome Heading atop the Hero */}
          <div className="absolute bottom-5 left-5 right-5 text-white z-10">
            <div className="flex items-center gap-2.5 mb-1.5">
              <div className="w-9 h-9 rounded-xl bg-teal-500/90 text-slate-950 flex items-center justify-center font-black text-sm tracking-tight shadow-md backdrop-blur-xs">
                SE
              </div>
              <div>
                <span className="text-xl font-black tracking-tight text-white">Stay</span>
                <span className="text-xl font-black tracking-tight text-teal-400">Ethio</span>
              </div>
            </div>
            <h1 className="text-lg font-bold text-white tracking-tight leading-snug">
              {mode === 'login' && 'Welcome back, traveler'}
              {mode === 'signup' && 'Create your StayEthio account'}
              {mode === 'otp' && 'Verify your mobile number'}
              {mode === 'forgot_password' && 'Recover your account'}
            </h1>
            <p className="text-xs text-slate-300 line-clamp-1">
              Addis Ababa · Bishoftu · Lalibela · Hawassa · Bahir Dar
            </p>
          </div>
        </div>

        {/* ============================================================== */}
        {/* ================ BODY CONTENT CONTAINER ===================== */}
        {/* ============================================================== */}
        <div className="flex-1 bg-white px-5 sm:px-8 py-6 flex flex-col justify-between">
          <div>
            {/* ========================================================== */}
            {/* ======================= 1. LOGIN SCREEN ================== */}
            {/* ========================================================== */}
            {mode === 'login' && (
              <div className="space-y-4">
                {/* Method Switcher Segmented Control */}
                <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginTab('phone');
                      setPhoneLoginError('');
                    }}
                    className={`py-2.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      loginTab === 'phone'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Phone className={`w-3.5 h-3.5 ${loginTab === 'phone' ? 'text-teal-600' : 'text-slate-400'}`} />
                    <span>Phone & SMS OTP</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLoginTab('email');
                      setLoginError('');
                    }}
                    className={`py-2.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      loginTab === 'email'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Mail className={`w-3.5 h-3.5 ${loginTab === 'email' ? 'text-teal-600' : 'text-slate-400'}`} />
                    <span>Email & Password</span>
                  </button>
                </div>

                {/* METHOD A: PHONE NUMBER + SMS OTP */}
                {loginTab === 'phone' && (
                  <form onSubmit={handleInitiatePhoneLogin} className="space-y-4 pt-1">
                    {phoneLoginError && (
                      <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                        <span>{phoneLoginError}</span>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        Ethiopian Mobile Number
                      </label>
                      <div className="flex rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                        {/* Fixed Country Code Badge */}
                        <div className="inline-flex items-center px-4 border-r border-slate-200 bg-slate-100/80 text-slate-800 font-bold text-xs gap-1.5 select-none shrink-0">
                          <span className="text-base leading-none" role="img" aria-label="Ethiopia flag">
                            🇪🇹
                          </span>
                          <span>+251</span>
                        </div>

                        <input
                          type="tel"
                          required
                          inputMode="numeric"
                          placeholder="91 123 4567"
                          value={formatPhoneDisplay(phoneLoginNumber)}
                          onChange={(e) => setPhoneLoginNumber(sanitizePhone(e.target.value))}
                          className="flex-1 block w-full py-3.5 px-3.5 bg-transparent text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none"
                        />
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1.5 flex items-center gap-1">
                        <span>Ethio Telecom (09...) or Safaricom Ethiopia (07...)</span>
                      </p>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3.5 px-5 bg-teal-600 hover:bg-teal-700 active:scale-[0.99] text-white text-xs font-bold rounded-2xl shadow-lg shadow-teal-700/20 transition-all flex items-center justify-center gap-2 cursor-pointer mt-1"
                    >
                      {isSubmitting ? (
                        <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      ) : (
                        <>
                          <span>Send 6-Digit SMS Code</span>
                          <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
                        </>
                      )}
                    </button>
                  </form>
                )}

                {/* METHOD B: EMAIL & PASSWORD */}
                {loginTab === 'email' && (
                  <form onSubmit={submitEmailLogin} className="space-y-3.5 pt-1">
                    {loginError && (
                      <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                        <span>{loginError}</span>
                      </div>
                    )}

                    {/* Email */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        Email Address
                      </label>
                      <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
                        <input
                          type="email"
                          required
                          placeholder="e.g. traveler@stayethio.com"
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          className="w-full pl-11 pr-4 py-3.5 bg-transparent text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Password */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="block text-xs font-bold text-slate-700">Password</label>
                        <button
                          type="button"
                          onClick={() => {
                            setMode('forgot_password');
                            setResetSent(false);
                            setForgotError('');
                          }}
                          className="text-xs font-bold text-teal-700 hover:text-teal-800 cursor-pointer"
                        >
                          Forgot password?
                        </button>
                      </div>
                      <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                        <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
                        <input
                          type={showLoginPassword ? 'text' : 'password'}
                          required
                          placeholder="Enter your account password"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="w-full pl-11 pr-11 py-3.5 bg-transparent text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600 cursor-pointer p-1"
                          title={showLoginPassword ? 'Hide password' : 'Show password'}
                        >
                          {showLoginPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Keep me signed in */}
                    <div className="flex items-center pt-0.5">
                      <input
                        id="remember_me"
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="h-4 w-4 rounded-md border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                      />
                      <label
                        htmlFor="remember_me"
                        className="ml-2 block text-xs font-medium text-slate-600 cursor-pointer select-none"
                      >
                        Keep me signed in on this device
                      </label>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3.5 px-5 bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-xs font-bold rounded-2xl shadow-lg shadow-slate-900/15 transition-all flex items-center justify-center gap-2 cursor-pointer mt-1"
                    >
                      {isSubmitting ? (
                        <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      ) : (
                        <span>Sign In</span>
                      )}
                    </button>
                  </form>
                )}

                {/* Divider & Google Sign In */}
                <div className="pt-2">
                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-slate-200"></div>
                    <span className="flex-shrink mx-3 text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
                      Or continue with
                    </span>
                    <div className="flex-grow border-t border-slate-200"></div>
                  </div>

                  <button
                    type="button"
                    onClick={handleGoogleSignInClick}
                    className="w-full py-3 px-4 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-2xl shadow-xs transition-all flex items-center justify-center gap-3 cursor-pointer active:scale-[0.99]"
                  >
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.94 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                      />
                    </svg>
                    <span>Continue with Google</span>
                  </button>
                </div>

                {/* Sign Up Navigation Link */}
                <div className="pt-2 text-center">
                  <p className="text-xs text-slate-600">
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setMode('signup');
                        setSignupError('');
                      }}
                      className="font-bold text-teal-700 hover:text-teal-800 cursor-pointer"
                    >
                      Create an account
                    </button>
                  </p>
                </div>
              </div>
            )}

            {/* ========================================================== */}
            {/* ======================= 2. SIGN UP SCREEN ================ */}
            {/* ========================================================== */}
            {mode === 'signup' && (
              <div className="space-y-4">
                {/* Account Type Selector (Traveler vs Hotel Partner only - no Admin) */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Select Account Role
                  </label>
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setSignupRole('guest')}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        signupRole === 'guest'
                          ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <User
                          className={`w-3.5 h-3.5 ${
                            signupRole === 'guest' ? 'text-teal-400' : 'text-slate-500'
                          }`}
                        />
                        <span className="text-xs font-bold">Traveler</span>
                      </div>
                      <p
                        className={`text-[11px] leading-tight ${
                          signupRole === 'guest' ? 'text-slate-300' : 'text-slate-500'
                        }`}
                      >
                        Book hotels & view stays
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSignupRole('owner')}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        signupRole === 'owner'
                          ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <Building
                          className={`w-3.5 h-3.5 ${
                            signupRole === 'owner' ? 'text-teal-400' : 'text-slate-500'
                          }`}
                        />
                        <span className="text-xs font-bold">Hotel Partner</span>
                      </div>
                      <p
                        className={`text-[11px] leading-tight ${
                          signupRole === 'owner' ? 'text-slate-300' : 'text-slate-500'
                        }`}
                      >
                        Manage hotels & bookings
                      </p>
                    </button>
                  </div>
                </div>

                {signupError && (
                  <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                    <span>{signupError}</span>
                  </div>
                )}

                <form onSubmit={submitSignup} className="space-y-3">
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Full Name
                    </label>
                    <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        placeholder="e.g. Abebe Kebede"
                        value={signupName}
                        onChange={(e) => setSignupName(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-transparent text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Ethiopian Mobile Number (Will receive OTP)
                    </label>
                    <div className="flex rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                      <span className="inline-flex items-center px-3 border-r border-slate-200 bg-slate-100 text-slate-800 font-bold text-xs gap-1 select-none shrink-0">
                        <span>🇪🇹</span>
                        <span>+251</span>
                      </span>
                      <input
                        type="tel"
                        required
                        inputMode="numeric"
                        placeholder="91 123 4567"
                        value={formatPhoneDisplay(signupPhone)}
                        onChange={(e) => setSignupPhone(sanitizePhone(e.target.value))}
                        className="flex-1 block w-full py-2.5 px-3 bg-transparent text-xs font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Email Address */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Email Address
                    </label>
                    <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        required
                        placeholder="name@example.com"
                        value={signupEmail}
                        onChange={(e) => setSignupEmail(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-transparent text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Password & Confirm */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Password
                      </label>
                      <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                        <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                        <input
                          type={showSignupPassword ? 'text' : 'password'}
                          required
                          placeholder="Min 6 chars"
                          value={signupPassword}
                          onChange={(e) => setSignupPassword(e.target.value)}
                          className="w-full pl-8 pr-8 py-2.5 bg-transparent text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setShowSignupPassword(!showSignupPassword)}
                          className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer p-1"
                        >
                          {showSignupPassword ? (
                            <EyeOff className="w-3.5 h-3.5" />
                          ) : (
                            <Eye className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Confirm Password
                      </label>
                      <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                        <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                        <input
                          type={showSignupPassword ? 'text' : 'password'}
                          required
                          placeholder="Repeat password"
                          value={signupConfirmPassword}
                          onChange={(e) => setSignupConfirmPassword(e.target.value)}
                          className="w-full pl-8 pr-3 py-2.5 bg-transparent text-xs font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Terms agreement */}
                  <div className="flex items-start pt-1">
                    <input
                      id="terms"
                      type="checkbox"
                      checked={agreeTerms}
                      onChange={(e) => setAgreeTerms(e.target.checked)}
                      className="h-4 w-4 mt-0.5 rounded-md border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                    />
                    <label
                      htmlFor="terms"
                      className="ml-2 block text-[11px] text-slate-600 leading-tight cursor-pointer select-none"
                    >
                      I agree to the StayEthio Terms of Service, Privacy Policy, and SMS verification.
                    </label>
                  </div>

                  {/* Submit Sign Up Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3 px-4 bg-teal-600 hover:bg-teal-700 active:scale-[0.99] text-white text-xs font-bold rounded-2xl shadow-lg shadow-teal-700/20 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    {isSubmitting ? (
                      <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    ) : (
                      <>
                        <span>Continue to Phone Verification (SMS OTP)</span>
                        <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
                      </>
                    )}
                  </button>
                </form>

                {/* Return to Sign In */}
                <div className="pt-2 text-center">
                  <p className="text-xs text-slate-600">
                    Already registered?{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setMode('login');
                        setSignupError('');
                      }}
                      className="font-bold text-teal-700 hover:text-teal-800 cursor-pointer"
                    >
                      Sign in
                    </button>
                  </p>
                </div>
              </div>
            )}

            {/* ========================================================== */}
            {/* ======================= 3. OTP SCREEN ==================== */}
            {/* ========================================================== */}
            {mode === 'otp' && (
              <div className="space-y-4">
                <button
                  type="button"
                  onClick={() => {
                    setMode(otpPurpose === 'signup_verification' ? 'signup' : 'login');
                    setOtpError('');
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-900 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to {otpPurpose === 'signup_verification' ? 'Sign Up' : 'Login'}</span>
                </button>

                <div className="text-center py-1">
                  <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-2 shadow-sm border border-teal-100">
                    <Phone className="w-6 h-6" />
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                    Verify Ethiopian Mobile
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Enter the 6-digit verification code sent via SMS to:
                  </p>
                  <div className="inline-flex items-center gap-2 mt-2 px-3 py-1 bg-slate-100 rounded-full text-xs font-bold text-slate-800">
                    <span>{otpTarget}</span>
                    <button
                      type="button"
                      onClick={() => setMode(otpPurpose === 'signup_verification' ? 'signup' : 'login')}
                      className="text-teal-700 hover:underline text-[11px]"
                    >
                      Edit
                    </button>
                  </div>
                </div>

                {otpSuccessMessage && (
                  <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200 text-xs text-teal-800 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-teal-600 mt-0.5" />
                    <span>{otpSuccessMessage}</span>
                  </div>
                )}

                {otpError && (
                  <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                    <span>{otpError}</span>
                  </div>
                )}

                <form onSubmit={submitVerifyOtp} className="space-y-4">
                  {/* 6 Individual Digit Input Boxes */}
                  <div className="flex justify-between gap-1.5 sm:gap-2 max-w-xs mx-auto">
                    {otpDigits.map((digit, idx) => (
                      <input
                        key={idx}
                        ref={(el) => {
                          otpInputsRef.current[idx] = el;
                        }}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                        className={`w-11 sm:w-12 h-14 text-center text-xl font-black rounded-2xl border transition-all ${
                          digit
                            ? 'border-teal-500 bg-teal-50/40 text-teal-900 ring-2 ring-teal-500/20'
                            : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-teal-500 focus:bg-white focus:ring-4 focus:ring-teal-500/15'
                        }`}
                      />
                    ))}
                  </div>

                  {/* Timers & Expiry Countdown */}
                  <div className="flex items-center justify-between text-xs px-1">
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>
                        Expires in:{' '}
                        <strong
                          className={`font-mono font-bold ${
                            expirySeconds <= 60 ? 'text-red-600' : 'text-slate-900'
                          }`}
                        >
                          {formatTimer(expirySeconds)}
                        </strong>
                      </span>
                    </div>

                    {resendCooldown > 0 ? (
                      <span className="text-[11px] font-medium text-slate-400">
                        Resend in {resendCooldown}s
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleResendOtp}
                        className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:text-teal-800 cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Resend Code</span>
                      </button>
                    )}
                  </div>

                  {/* Transparent SMS Integration Notice */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 leading-relaxed space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-slate-800">
                      <Info className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span>SMS Gateway (Preview Mode):</span>
                    </div>
                    <p>
                      Real SMS delivery requires Ethio Telecom SMS API or Twilio credentials. In this
                      preview step, enter any 6 digits (e.g. <span className="font-mono font-bold text-teal-700">123456</span>)
                      to verify and activate your session.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={isOtpVerifying}
                    className="w-full py-3.5 px-4 bg-teal-600 hover:bg-teal-700 active:scale-[0.99] text-white text-xs font-bold rounded-2xl shadow-lg shadow-teal-700/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isOtpVerifying ? (
                      <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    ) : (
                      <span>
                        {otpPurpose === 'signup_verification'
                          ? 'Verify & Activate Account'
                          : 'Verify & Sign In'}
                      </span>
                    )}
                  </button>
                </form>
              </div>
            )}

            {/* ========================================================== */}
            {/* =================== 4. FORGOT PASSWORD =================== */}
            {/* ========================================================== */}
            {mode === 'forgot_password' && (
              <div className="space-y-4">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setResetSent(false);
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-900 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>

                <div className="text-center py-1">
                  <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mx-auto mb-2 border border-teal-100 shadow-sm">
                    <KeyRound className="w-6 h-6" />
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                    Reset Your Password
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Select your preferred account recovery channel
                  </p>
                </div>

                {resetSent ? (
                  <div className="space-y-4 pt-2">
                    <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 text-teal-900 space-y-2">
                      <div className="flex items-center gap-2 font-bold text-xs">
                        <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                        <span>Recovery Instructions Prepared</span>
                      </div>
                      <p className="text-xs text-teal-800 leading-relaxed">
                        Instructions have been routed for{' '}
                        <strong className="font-semibold text-teal-950">
                          {forgotRecoveryMethod === 'email' ? forgotEmail : `+251 ${formatPhoneDisplay(forgotPhone)}`}
                        </strong>
                        .
                      </p>
                      <p className="text-[11px] text-teal-700 pt-1 border-t border-teal-200/60">
                        (Note: Outbound SMTP email / SMS gateway dispatcher is required in production to send live messages).
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setMode('login');
                        setResetSent(false);
                      }}
                      className="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-2xl transition-all cursor-pointer shadow-md"
                    >
                      Return to Sign In
                    </button>
                  </div>
                ) : (
                  <form onSubmit={submitForgotPassword} className="space-y-4 pt-1">
                    {/* Recovery Method Segmented Control */}
                    <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl">
                      <button
                        type="button"
                        onClick={() => setForgotRecoveryMethod('email')}
                        className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                          forgotRecoveryMethod === 'email'
                            ? 'bg-white text-slate-900 shadow-sm'
                            : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        Email Address
                      </button>
                      <button
                        type="button"
                        onClick={() => setForgotRecoveryMethod('phone')}
                        className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                          forgotRecoveryMethod === 'phone'
                            ? 'bg-white text-slate-900 shadow-sm'
                            : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        Mobile Phone
                      </button>
                    </div>

                    {forgotError && (
                      <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                        <span>{forgotError}</span>
                      </div>
                    )}

                    {forgotRecoveryMethod === 'email' ? (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5">
                          Registered Email
                        </label>
                        <div className="relative rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                          <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
                          <input
                            type="email"
                            required
                            placeholder="e.g. traveler@stayethio.com"
                            value={forgotEmail}
                            onChange={(e) => setForgotEmail(e.target.value)}
                            className="w-full pl-11 pr-4 py-3.5 bg-transparent text-sm font-medium text-slate-900 focus:outline-none"
                          />
                        </div>
                      </div>
                    ) : (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5">
                          Registered Mobile Number
                        </label>
                        <div className="flex rounded-2xl shadow-xs border border-slate-200 focus-within:border-teal-500 focus-within:ring-4 focus-within:ring-teal-500/10 transition-all bg-slate-50/80 focus-within:bg-white overflow-hidden">
                          <span className="inline-flex items-center px-4 border-r border-slate-200 bg-slate-100 text-slate-800 font-bold text-xs gap-1.5 select-none shrink-0">
                            <span>🇪🇹</span>
                            <span>+251</span>
                          </span>
                          <input
                            type="tel"
                            required
                            inputMode="numeric"
                            placeholder="91 123 4567"
                            value={formatPhoneDisplay(forgotPhone)}
                            onChange={(e) => setForgotPhone(sanitizePhone(e.target.value))}
                            className="flex-1 block w-full py-3.5 px-3.5 bg-transparent text-sm font-semibold text-slate-900 focus:outline-none"
                          />
                        </div>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3.5 px-4 bg-teal-600 hover:bg-teal-700 active:scale-[0.99] text-white text-xs font-bold rounded-2xl shadow-lg shadow-teal-700/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isSubmitting ? (
                        <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      ) : (
                        <span>Send Recovery Instructions</span>
                      )}
                    </button>
                  </form>
                )}
              </div>
            )}
          </div>

          {/* Clean Security Footer */}
          <div className="pt-6 mt-4 border-t border-slate-100 text-center">
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-600 shrink-0" />
              <span>StayEthio Secure Hospitality Network · 256-Bit SSL</span>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* ================ GOOGLE SIGN-IN STATUS MODAL ================= */}
      {/* ============================================================== */}
      {showGoogleInfoModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 border border-blue-100">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.94 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900">
                  Google Sign-In Integration Status
                </h3>
                <p className="text-xs text-slate-500">OAuth 2.0 Client Authentication</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed mb-6">
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900">
                <span className="font-bold block mb-1">UI Ready · Backend Pending</span>
                Live Google Sign-In requires configuring a Google Cloud OAuth 2.0 Client ID or Firebase Google Provider.
              </div>
              <p>
                In compliance with transparent verification standards, we do not fake network authentication. You can continue with your verified development account profile to test the full StayEthio hotel booking experience.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={handleContinueWithGoogleProfile}
                className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-bold transition-colors cursor-pointer shadow-md"
              >
                Continue with Test Profile
              </button>
              <button
                type="button"
                onClick={() => setShowGoogleInfoModal(false)}
                className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl text-xs font-bold transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
