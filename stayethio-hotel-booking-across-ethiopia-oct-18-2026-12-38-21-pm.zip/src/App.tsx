import React, { useState } from 'react';
import {
  Search,
  Calendar,
  Users,
  MapPin,
  Star,
  ShieldCheck,
  Check,
  CreditCard,
  Building,
  Smartphone,
  ChevronRight,
  ArrowLeft,
  Filter,
  DollarSign,
  QrCode,
  X,
  Plus,
  Briefcase,
  UserCheck,
  Receipt,
  Bed,
  Wifi,
  Coffee,
  Waves,
  Sparkles,
  Plane,
  AlertCircle,
  LogIn,
  LogOut,
  User
} from 'lucide-react';
import { ETHIOPIAN_CITIES, INITIAL_HOTELS, INITIAL_BOOKINGS, REVIEWS } from './data/hotels';
import { Hotel, RoomType, Booking, UserRole, PaymentMethod, BookingStatus, UserProfile } from './types';
import AuthScreens from './components/AuthScreens';

export default function App() {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('stayethio_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isGuestExploration, setIsGuestExploration] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Navigation & Role State
  const [currentRole, setCurrentRole] = useState<UserRole>('guest');
  const [activeTab, setActiveTab] = useState<'home' | 'hotel_detail' | 'booking' | 'my_bookings'>('home');
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<RoomType | null>(null);
  const [voucherModalBooking, setVoucherModalBooking] = useState<Booking | null>(null);

  // Currency State (ETB vs USD)
  const [isUsd, setIsUsd] = useState(false);
  const ETB_TO_USD = 122.5;

  const formatPrice = (amountEtb: number) => {
    if (isUsd) {
      return `$${Math.round(amountEtb / ETB_TO_USD).toLocaleString()} USD`;
    }
    return `${Math.round(amountEtb).toLocaleString()} ETB`;
  };

  // Search & Filter State
  const [searchCity, setSearchCity] = useState<string>('All Cities');
  const [checkInDate, setCheckInDate] = useState('2026-10-24');
  const [checkOutDate, setCheckOutDate] = useState('2026-10-27');
  const [guestCount, setGuestCount] = useState(2);
  const [selectedStars, setSelectedStars] = useState<number | null>(null);
  const [maxPrice, setMaxPrice] = useState(35000);
  const [filterAmenity, setFilterAmenity] = useState<string>('');
  const [showFilterModal, setShowFilterModal] = useState(false);

  // Data State
  const [hotelsList, setHotelsList] = useState<Hotel[]>(INITIAL_HOTELS);
  const [bookingsList, setBookingsList] = useState<Booking[]>(INITIAL_BOOKINGS);

  // Booking Form State
  const [guestName, setGuestName] = useState('Yakin Yohannes');
  const [guestPhone, setGuestPhone] = useState('+251 91 123 4567');
  const [guestEmail, setGuestEmail] = useState('yakin.travel@example.com');
  const [specialRequests, setSpecialRequests] = useState('Arriving via Bole airport flight ET302. Please arrange shuttle pickup.');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('telebirr');
  const [telebirrMobile, setTelebirrMobile] = useState('+251 91 123 4567');
  const [bankRefCode, setBankRefCode] = useState('CBE-TX-998412');
  const [isSubmittingBooking, setIsSubmittingBooking] = useState(false);

  // Hotel Owner State
  const [ownerActiveTab, setOwnerActiveTab] = useState<'listings' | 'requests'>('listings');
  const [showAddHotelModal, setShowAddHotelModal] = useState(false);
  const [newHotelName, setNewHotelName] = useState('Simien Escarpment Eco-Lodge');
  const [newHotelCity, setNewHotelCity] = useState('Gondar');
  const [newHotelArea, setNewHotelArea] = useState('Simien Mountains');
  const [newHotelAddress, setNewHotelAddress] = useState('Debark Ridge, Simien National Park, Ethiopia');
  const [newHotelPrice, setNewHotelPrice] = useState('8500');
  const [newHotelDesc, setNewHotelDesc] = useState('Exclusive stone and timber highland lodge with panoramic mountain vistas and guided endemic wildlife tours.');

  // Admin State
  const [adminActiveTab, setAdminActiveTab] = useState<'approvals' | 'ledger'>('approvals');

  // Filtered Hotels
  const filteredHotels = hotelsList.filter((hotel) => {
    const matchesCity = searchCity === 'All Cities' || hotel.city.toLowerCase() === searchCity.toLowerCase();
    const matchesPrice = hotel.startingPriceEtb <= maxPrice;
    const matchesStars = selectedStars === null || hotel.starRating >= selectedStars;
    const matchesAmenity = !filterAmenity || hotel.amenities.some(a => a.toLowerCase().includes(filterAmenity.toLowerCase()));
    return matchesCity && matchesPrice && matchesStars && matchesAmenity;
  });

  // Calculate nights
  const calculateNights = () => {
    try {
      const d1 = new Date(checkInDate);
      const d2 = new Date(checkOutDate);
      const diffTime = Math.abs(d2.getTime() - d1.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 ? diffDays : 1;
    } catch {
      return 3;
    }
  };
  const nights = calculateNights();

  // Create Booking Action
  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHotel || !selectedRoom) return;

    setIsSubmittingBooking(true);
    setTimeout(() => {
      const subtotal = selectedRoom.pricePerNightEtb * nights;
      const taxes = subtotal * 0.15;
      const total = subtotal + taxes;
      const refCode = `ETH-${Math.floor(10000 + Math.random() * 90000)}`;

      let payStatus = 'Paid (Telebirr Verified)';
      if (paymentMethod === 'bank_transfer') payStatus = 'Pending Bank Slip Audit';
      if (paymentMethod === 'cash_on_arrival') payStatus = 'Due on Arrival';

      const newBooking: Booking = {
        id: `bk_${Date.now()}`,
        referenceCode: refCode,
        hotelId: selectedHotel.id,
        hotelName: selectedHotel.name,
        hotelCity: selectedHotel.city,
        hotelImage: selectedHotel.mainImage,
        roomTypeName: selectedRoom.name,
        checkInDate,
        checkOutDate,
        nightsCount: nights,
        guestCount,
        guestFullName: guestName,
        guestPhone,
        guestEmail,
        specialRequests,
        subtotalEtb: subtotal,
        taxesEtb: taxes,
        totalAmountEtb: total,
        paymentType: paymentMethod,
        paymentStatus: payStatus,
        bookingStatus: 'confirmed',
        createdAt: 'Just now',
        bankTransactionRef: paymentMethod === 'bank_transfer' ? bankRefCode : undefined,
        telebirrPhone: paymentMethod === 'telebirr' ? telebirrMobile : undefined,
      };

      setBookingsList([newBooking, ...bookingsList]);
      setIsSubmittingBooking(false);
      setVoucherModalBooking(newBooking);
      setActiveTab('my_bookings');
    }, 600);
  };

  // Cancel Booking
  const handleCancelBooking = (bookingId: string) => {
    if (window.confirm('Are you sure you want to cancel this reservation? Free cancellation applies up to 48 hours before check-in.')) {
      setBookingsList(bookingsList.map(b => b.id === bookingId ? { ...b, bookingStatus: 'cancelled' } : b));
    }
  };

  // Add Hotel Handler
  const handleAddHotel = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(newHotelPrice) || 6000;
    const newH: Hotel = {
      id: `hotel_${Date.now()}`,
      name: newHotelName,
      city: newHotelCity,
      subCityOrArea: newHotelArea,
      fullAddress: newHotelAddress,
      starRating: 4,
      reviewScore: 5.0,
      reviewCount: 1,
      startingPriceEtb: priceNum,
      mainImage: '/images/hotel_hero.jpg',
      galleryImages: ['/images/hotel_hero.jpg', '/images/hotel_room.jpg'],
      description: newHotelDesc,
      highlights: ['Scenic Highland Views', 'Buna Coffee Experience', 'Free Shuttle'],
      amenities: ['High-Speed WiFi', 'Free Breakfast', 'Airport Transfer', 'Scenic Terrace'],
      rooms: [
        {
          id: `room_${Date.now()}`,
          name: 'Highland Escarpment Suite',
          description: 'Spacious stone lodge room with panoramic canyon views and fireplace.',
          bedType: '1 King Bed',
          maxGuests: 2,
          pricePerNightEtb: priceNum,
          sizeSqMeters: 44,
          amenities: ['Mountain View', 'Breakfast Included', 'WiFi'],
          image: '/images/hotel_room.jpg',
        }
      ],
      isFeatured: false,
      isVerified: false,
      ownerId: 'owner_user',
    };

    setHotelsList([newH, ...hotelsList]);
    setShowAddHotelModal(false);
  };

  // Handler for login/signup success
  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('stayethio_auth_user', JSON.stringify(user));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    setIsGuestExploration(false);
    setAuthModalOpen(false);
    if (user.role === 'owner') {
      setCurrentRole('owner');
    } else if (user.role === 'admin') {
      setCurrentRole('admin');
    } else {
      setCurrentRole('guest');
      setActiveTab('home');
    }

    setGuestName(user.name);
    setGuestEmail(user.email);
    setGuestPhone(user.phone);
  };

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out from StayEthio?')) {
      setCurrentUser(null);
      try {
        localStorage.removeItem('stayethio_auth_user');
      } catch (e) {
        console.warn('LocalStorage error:', e);
      }
      setIsGuestExploration(false);
      setActiveTab('home');
      setCurrentRole('guest');
    }
  };

  // Requirement: Show the Login screen when the app opens
  if (!currentUser && !isGuestExploration) {
    return (
      <AuthScreens
        initialMode="login"
        onLoginSuccess={handleAuthSuccess}
        onExploreAsGuest={() => setIsGuestExploration(true)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col antialiased">
      {/* Top Bar Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Wordmark Logo */}
            <div
              onClick={() => { setActiveTab('home'); setCurrentRole('guest'); }}
              className="flex items-center gap-3 cursor-pointer group shrink-0"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center shadow-sm">
                <span className="text-teal-400 font-extrabold text-lg tracking-tight">SE</span>
              </div>
              <div>
                <div className="flex items-center text-xl font-black tracking-tight leading-none">
                  <span className="text-slate-900">Stay</span>
                  <span className="text-teal-600">Ethio</span>
                </div>
                <p className="text-[10px] text-slate-500 font-medium tracking-wide">
                  Ethiopian Hotel Booking
                </p>
              </div>
            </div>

            {/* Role Switcher Center */}
            <div className="hidden md:flex items-center bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => { setCurrentRole('guest'); setActiveTab('home'); }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  currentRole === 'guest'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Traveler View
              </button>
              <button
                onClick={() => setCurrentRole('owner')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  currentRole === 'owner'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Hotel Partner
              </button>
              {currentUser?.role === 'admin' && (
                <button
                  onClick={() => setCurrentRole('admin')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    currentRole === 'admin'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Admin Console
                </button>
              )}
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-3 shrink-0">
              {/* Currency Toggle */}
              <button
                onClick={() => setIsUsd(!isUsd)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800 transition-colors"
                title="Toggle between Ethiopian Birr and USD"
              >
                <DollarSign className="w-3.5 h-3.5 text-teal-600" />
                <span>{isUsd ? 'USD ($)' : 'ETB (ብር)'}</span>
              </button>

              {/* Bookings Link */}
              <button
                onClick={() => { setCurrentRole('guest'); setActiveTab('my_bookings'); }}
                className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                  activeTab === 'my_bookings' && currentRole === 'guest'
                    ? 'bg-teal-600 text-white'
                    : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
                }`}
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">My Stays</span>
                <span className="w-5 h-5 rounded-full bg-teal-700 text-white text-[10px] flex items-center justify-center font-bold">
                  {bookingsList.length}
                </span>
              </button>

              {/* User Profile & Auth Trigger */}
              {currentUser ? (
                <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                  <div className="flex items-center gap-1.5">
                    <div className="w-8 h-8 rounded-full bg-slate-900 text-teal-400 flex items-center justify-center font-bold text-xs uppercase shadow-xs">
                      {currentUser.name.charAt(0)}
                    </div>
                    <div className="hidden lg:block text-left leading-tight">
                      <span className="text-xs font-bold text-slate-900 block truncate max-w-[100px]">
                        {currentUser.name}
                      </span>
                      <span className="text-[10px] text-teal-700 font-semibold uppercase">
                        {currentUser.role === 'owner' ? 'Partner' : currentUser.role}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    title="Log Out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setAuthModalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-xs"
                >
                  <LogIn className="w-3.5 h-3.5 text-teal-400" />
                  <span>Sign In</span>
                </button>
              )}
            </div>
          </div>

          {/* Mobile Role Switcher Strip */}
          <div className="flex md:hidden items-center justify-between py-2 border-t border-slate-100 text-xs">
            <span className="text-slate-500 font-semibold text-[11px]">
              {currentUser ? `Hi, ${currentUser.name.split(' ')[0]}` : 'Portal Mode:'}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => { setCurrentRole('guest'); setActiveTab('home'); }}
                className={`px-2 py-1 text-[11px] font-semibold rounded-md ${currentRole === 'guest' ? 'bg-slate-900 text-white' : 'text-slate-600'}`}
              >
                Traveler
              </button>
              <button
                onClick={() => setCurrentRole('owner')}
                className={`px-2 py-1 text-[11px] font-semibold rounded-md ${currentRole === 'owner' ? 'bg-slate-900 text-white' : 'text-slate-600'}`}
              >
                Partner
              </button>
              {currentUser?.role === 'admin' && (
                <button
                  onClick={() => setCurrentRole('admin')}
                  className={`px-2 py-1 text-[11px] font-semibold rounded-md ${currentRole === 'admin' ? 'bg-slate-900 text-white' : 'text-slate-600'}`}
                >
                  Admin
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Body depending on Persona */}
      <main className="flex-1">
        {/* ================= GUEST VIEW ================= */}
        {currentRole === 'guest' && (
          <>
            {activeTab === 'home' && (
              <div>
                {/* Hero Banner Section */}
                <div className="relative bg-slate-900 text-white">
                  <div className="absolute inset-0 overflow-hidden">
                    <img
                      src="/images/hotel_hero.jpg"
                      alt="Ethiopian Luxury Hospitality"
                      className="w-full h-full object-cover opacity-40 scale-105 transition-transform duration-1000"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent" />
                  </div>

                  <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24 md:pt-24 md:pb-32">
                    <div className="max-w-2xl">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 border border-teal-400/30 text-teal-300 text-xs font-semibold mb-4">
                        <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                        <span>AUTHENTIC ETHIOPIAN HOSPITALITY</span>
                      </div>
                      <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
                        Experience Premier Stays Across Ethiopia
                      </h1>
                      <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed">
                        Discover 5-star airport luxury in Addis Ababa, tranquil volcanic crater resorts in Bishoftu, UNESCO cliffside mountain lodges in Lalibela, and Lake Tana retreats.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Floating Search Card */}
                <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 sm:-mt-16 relative z-20">
                  <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-4 sm:p-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {/* Destination City */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Destination City
                        </label>
                        <div className="relative">
                          <MapPin className="w-4 h-4 text-teal-600 absolute left-3 top-3.5" />
                          <select
                            value={searchCity}
                            onChange={(e) => setSearchCity(e.target.value)}
                            className="w-full pl-9 pr-8 py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                          >
                            {ETHIOPIAN_CITIES.map((city) => (
                              <option key={city} value={city}>
                                {city}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Dates: Check-in & Check-out */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Check-In Date
                        </label>
                        <div className="relative">
                          <Calendar className="w-4 h-4 text-teal-600 absolute left-3 top-3.5" />
                          <input
                            type="date"
                            value={checkInDate}
                            onChange={(e) => setCheckInDate(e.target.value)}
                            className="w-full pl-9 pr-3 py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Check-Out Date
                        </label>
                        <div className="relative">
                          <Calendar className="w-4 h-4 text-teal-600 absolute left-3 top-3.5" />
                          <input
                            type="date"
                            value={checkOutDate}
                            onChange={(e) => setCheckOutDate(e.target.value)}
                            className="w-full pl-9 pr-3 py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                          />
                        </div>
                      </div>

                      {/* Guests & Filter Trigger */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Guests & Filters
                        </label>
                        <div className="flex items-center gap-2">
                          <div className="relative flex-1">
                            <Users className="w-4 h-4 text-teal-600 absolute left-3 top-3.5" />
                            <select
                              value={guestCount}
                              onChange={(e) => setGuestCount(Number(e.target.value))}
                              className="w-full pl-9 pr-4 py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                            >
                              <option value={1}>1 Guest</option>
                              <option value={2}>2 Guests</option>
                              <option value={3}>3 Guests</option>
                              <option value={4}>4+ Family</option>
                            </select>
                          </div>
                          <button
                            onClick={() => setShowFilterModal(true)}
                            className={`p-2.5 rounded-xl border transition-colors ${
                              selectedStars || maxPrice < 35000 || filterAmenity
                                ? 'bg-teal-600 text-white border-teal-600'
                                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                            }`}
                            title="Filter options"
                          >
                            <Filter className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Ethiopian Popular Destinations Bar */}
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
                  <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                    <span className="text-xs font-bold text-slate-400 shrink-0">Popular:</span>
                    {ETHIOPIAN_CITIES.map((city) => (
                      <button
                        key={city}
                        onClick={() => setSearchCity(city)}
                        className={`px-3.5 py-1.5 text-xs font-semibold rounded-full border transition-all shrink-0 ${
                          searchCity === city
                            ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {city}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Ethiopian Payment Trust Banner */}
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                  <div className="bg-teal-50/60 border border-teal-100 rounded-xl p-3.5 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-teal-600 text-white flex items-center justify-center shrink-0">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                          Secure Ethiopian Payment Options Supported
                        </h4>
                        <p className="text-xs text-slate-600">
                          Instant Telebirr integration, direct CBE / Awash bank transfer, and guaranteed cash on arrival.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 self-end sm:self-auto text-xs font-semibold text-teal-800">
                      <span className="px-2.5 py-1 rounded-md bg-white border border-teal-200 text-[11px]">Telebirr</span>
                      <span className="px-2.5 py-1 rounded-md bg-white border border-teal-200 text-[11px]">CBE Transfer</span>
                      <span className="px-2.5 py-1 rounded-md bg-white border border-teal-200 text-[11px]">Cash on Arrival</span>
                    </div>
                  </div>
                </div>

                {/* Hotel Listings Grid */}
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                        {searchCity === 'All Cities' ? 'Featured Stays in Ethiopia' : `Hotels in ${searchCity}`}
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                        {filteredHotels.length} verified accommodations available for {nights} nights
                      </p>
                    </div>

                    {(searchCity !== 'All Cities' || selectedStars || maxPrice < 35000 || filterAmenity) && (
                      <button
                        onClick={() => {
                          setSearchCity('All Cities');
                          setSelectedStars(null);
                          setMaxPrice(35000);
                          setFilterAmenity('');
                        }}
                        className="text-xs font-bold text-teal-700 hover:text-teal-800"
                      >
                        Reset filters
                      </button>
                    )}
                  </div>

                  {filteredHotels.length === 0 ? (
                    <div className="text-center py-16 bg-slate-50 rounded-2xl border border-slate-200">
                      <Building className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                      <h3 className="text-base font-bold text-slate-800">No matching Ethiopian hotels found</h3>
                      <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                        Try clearing some filters or searching for "All Cities" to explore accommodations.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                      {filteredHotels.map((hotel) => (
                        <div
                          key={hotel.id}
                          className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all flex flex-col group"
                        >
                          {/* Image Box */}
                          <div className="relative h-56 sm:h-64 overflow-hidden bg-slate-100">
                            <img
                              src={hotel.mainImage}
                              alt={hotel.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            {/* City / Area Tag */}
                            <div className="absolute top-3 left-3 bg-slate-900/85 backdrop-blur-xs text-white px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs">
                              <MapPin className="w-3.5 h-3.5 text-teal-400" />
                              <span>{hotel.city} · {hotel.subCityOrArea}</span>
                            </div>

                            {/* Score Tag */}
                            <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-lg text-xs font-bold text-slate-900 shadow-sm flex items-center gap-1">
                              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                              <span>{hotel.reviewScore}</span>
                              <span className="text-slate-400 font-normal">({hotel.reviewCount})</span>
                            </div>

                            {/* Verified Badge */}
                            {hotel.isVerified && (
                              <div className="absolute bottom-3 left-3 bg-teal-800/90 backdrop-blur-xs text-white px-2 py-0.5 rounded-md text-[10px] font-bold tracking-wide uppercase flex items-center gap-1">
                                <ShieldCheck className="w-3 h-3 text-teal-300" />
                                <span>Verified Partner</span>
                              </div>
                            )}
                          </div>

                          {/* Card Content */}
                          <div className="p-5 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center justify-between gap-2">
                                <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                                  {hotel.name}
                                </h3>
                                <div className="flex text-amber-400">
                                  {Array.from({ length: hotel.starRating }).map((_, i) => (
                                    <Star key={i} className="w-3 h-3 fill-amber-400" />
                                  ))}
                                </div>
                              </div>

                              <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                                {hotel.description}
                              </p>

                              {/* Highlights */}
                              <div className="mt-4 flex flex-wrap gap-1.5">
                                {hotel.highlights.slice(0, 2).map((hl, i) => (
                                  <span
                                    key={i}
                                    className="px-2 py-1 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                                  >
                                    {hl}
                                  </span>
                                ))}
                              </div>
                            </div>

                            {/* Price and CTA */}
                            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                              <div>
                                <span className="text-[11px] text-slate-400 font-medium block">Starting from</span>
                                <div className="flex items-baseline gap-1">
                                  <span className="text-lg font-black text-slate-900">
                                    {formatPrice(hotel.startingPriceEtb)}
                                  </span>
                                  <span className="text-xs text-slate-500">/ night</span>
                                </div>
                              </div>

                              <button
                                onClick={() => {
                                  setSelectedHotel(hotel);
                                  setSelectedRoom(hotel.rooms[0]);
                                  setActiveTab('hotel_detail');
                                }}
                                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
                              >
                                View Rooms
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ================= HOTEL DETAILS PAGE ================= */}
            {activeTab === 'hotel_detail' && selectedHotel && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Back button */}
                <button
                  onClick={() => setActiveTab('home')}
                  className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 mb-6 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Search Results</span>
                </button>

                {/* Header Information */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex text-amber-400">
                        {Array.from({ length: selectedHotel.starRating }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-amber-400" />
                        ))}
                      </div>
                      <span className="text-xs font-bold text-slate-600">
                        {selectedHotel.reviewScore} · {selectedHotel.reviewCount} reviews
                      </span>
                      {selectedHotel.isVerified && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 text-[10px] font-bold">
                          <ShieldCheck className="w-3 h-3" />
                          Verified
                        </span>
                      )}
                    </div>
                    <h1 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
                      {selectedHotel.name}
                    </h1>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                      <MapPin className="w-3.5 h-3.5 text-teal-600" />
                      <span>{selectedHotel.fullAddress}</span>
                    </div>
                  </div>

                  <div className="text-left md:text-right">
                    <span className="text-xs text-slate-400 font-medium block">Starting rate</span>
                    <span className="text-2xl font-black text-slate-900">
                      {formatPrice(selectedHotel.startingPriceEtb)}
                    </span>
                    <span className="text-xs text-slate-500"> / night</span>
                  </div>
                </div>

                {/* Photo Gallery Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 h-96">
                  <div className="md:col-span-2 rounded-2xl overflow-hidden bg-slate-100 h-full">
                    <img
                      src={selectedHotel.mainImage}
                      alt={selectedHotel.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-1 gap-4 h-full">
                    {selectedHotel.galleryImages.slice(1, 3).map((img, i) => (
                      <div key={i} className="rounded-2xl overflow-hidden bg-slate-100 h-full">
                        <img src={img} alt="Hotel preview" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Content Columns */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 mt-10">
                  {/* Left Column: Overview, Highlights, Amenities, Rooms */}
                  <div className="lg:col-span-2 space-y-10">
                    {/* About */}
                    <div>
                      <h2 className="text-lg font-bold text-slate-900 mb-3">About This Property</h2>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {selectedHotel.description}
                      </p>
                    </div>

                    {/* Key Highlights */}
                    <div>
                      <h2 className="text-lg font-bold text-slate-900 mb-3">Ethiopian Highlights</h2>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {selectedHotel.highlights.map((hl, i) => (
                          <div key={i} className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs font-semibold text-slate-800">
                            <Check className="w-4 h-4 text-teal-600 shrink-0" />
                            <span>{hl}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Amenities Matrix */}
                    <div>
                      <h2 className="text-lg font-bold text-slate-900 mb-3">Hotel Amenities</h2>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        {selectedHotel.amenities.map((am, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs text-slate-700">
                            <div className="w-1.5 h-1.5 rounded-full bg-teal-600" />
                            <span>{am}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Room Selection */}
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h2 className="text-xl font-black text-slate-900">Available Room Types</h2>
                          <p className="text-xs text-slate-500">All rooms include free breakfast and coffee ceremony</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        {selectedHotel.rooms.map((room) => {
                          const isSelected = selectedRoom?.id === room.id;
                          return (
                            <div
                              key={room.id}
                              onClick={() => setSelectedRoom(room)}
                              className={`p-5 rounded-2xl border-2 transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-teal-600 bg-teal-50/20 shadow-md'
                                  : 'border-slate-200 bg-white hover:border-slate-300'
                              }`}
                            >
                              <div className="flex flex-col sm:flex-row justify-between gap-4">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <h3 className="text-base font-bold text-slate-900">{room.name}</h3>
                                    {isSelected && (
                                      <span className="px-2 py-0.5 rounded-md bg-teal-600 text-white text-[10px] font-bold">
                                        Selected
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-slate-500 mt-1">{room.description}</p>

                                  <div className="flex flex-wrap gap-4 mt-3 text-xs text-slate-600 font-medium">
                                    <span className="flex items-center gap-1">
                                      <Bed className="w-3.5 h-3.5 text-teal-600" />
                                      {room.bedType}
                                    </span>
                                    <span className="flex items-center gap-1">
                                      <Users className="w-3.5 h-3.5 text-teal-600" />
                                      Up to {room.maxGuests} Guests
                                    </span>
                                    <span>{room.sizeSqMeters} m²</span>
                                  </div>

                                  <div className="flex flex-wrap gap-1.5 mt-3">
                                    {room.amenities.map((a, i) => (
                                      <span key={i} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                                        {a}
                                      </span>
                                    ))}
                                  </div>
                                </div>

                                <div className="text-left sm:text-right shrink-0 flex sm:flex-col justify-between items-end">
                                  <div>
                                    <span className="text-lg font-black text-slate-900 block">
                                      {formatPrice(room.pricePerNightEtb)}
                                    </span>
                                    <span className="text-xs text-slate-500">per night</span>
                                  </div>

                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedRoom(room);
                                      setActiveTab('booking');
                                    }}
                                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                                      isSelected
                                        ? 'bg-teal-600 text-white hover:bg-teal-700'
                                        : 'bg-slate-900 text-white hover:bg-slate-800'
                                    }`}
                                  >
                                    Reserve Room
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Guest Reviews */}
                    <div>
                      <h2 className="text-lg font-bold text-slate-900 mb-4">Guest Reviews</h2>
                      <div className="space-y-3">
                        {REVIEWS.map((rev) => (
                          <div key={rev.id} className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900">{rev.authorName}</span>
                              <div className="flex text-amber-400">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star key={i} className="w-3 h-3 fill-amber-400" />
                                ))}
                              </div>
                            </div>
                            <span className="text-[11px] text-slate-400">{rev.cityOrCountry} · {rev.date}</span>
                            <p className="text-xs text-slate-600 mt-2 leading-relaxed">{rev.comment}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Sticky Summary Card */}
                  <div>
                    <div className="sticky top-24 bg-white rounded-2xl border border-slate-200 p-6 shadow-lg">
                      <h3 className="text-base font-bold text-slate-900 mb-4">Your Reservation Summary</h3>

                      <div className="space-y-3 text-xs border-b border-slate-100 pb-4">
                        <div className="flex justify-between text-slate-600">
                          <span>Check-in:</span>
                          <span className="font-bold text-slate-900">{checkInDate}</span>
                        </div>
                        <div className="flex justify-between text-slate-600">
                          <span>Check-out:</span>
                          <span className="font-bold text-slate-900">{checkOutDate}</span>
                        </div>
                        <div className="flex justify-between text-slate-600">
                          <span>Length of Stay:</span>
                          <span className="font-bold text-slate-900">{nights} Nights</span>
                        </div>
                        <div className="flex justify-between text-slate-600">
                          <span>Guests:</span>
                          <span className="font-bold text-slate-900">{guestCount} Guests</span>
                        </div>
                        <div className="flex justify-between text-slate-600">
                          <span>Selected Room:</span>
                          <span className="font-bold text-teal-700">{selectedRoom?.name}</span>
                        </div>
                      </div>

                      {/* Pricing summary */}
                      {selectedRoom && (
                        <div className="py-4 space-y-2 text-xs border-b border-slate-100">
                          <div className="flex justify-between text-slate-600">
                            <span>{formatPrice(selectedRoom.pricePerNightEtb)} × {nights} nights</span>
                            <span className="font-semibold text-slate-900">
                              {formatPrice(selectedRoom.pricePerNightEtb * nights)}
                            </span>
                          </div>
                          <div className="flex justify-between text-slate-600">
                            <span>Ethiopian VAT & Service (15%)</span>
                            <span className="font-semibold text-slate-900">
                              {formatPrice(selectedRoom.pricePerNightEtb * nights * 0.15)}
                            </span>
                          </div>
                          <div className="flex justify-between text-sm font-black text-slate-900 pt-2">
                            <span>Total Payable</span>
                            <span className="text-teal-700 text-lg">
                              {formatPrice(selectedRoom.pricePerNightEtb * nights * 1.15)}
                            </span>
                          </div>
                        </div>
                      )}

                      <button
                        onClick={() => setActiveTab('booking')}
                        className="w-full mt-6 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold shadow-md transition-colors"
                      >
                        Proceed to Booking
                      </button>

                      <p className="text-[11px] text-slate-400 text-center mt-3">
                        Free cancellation up to 48 hours prior to check-in.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ================= BOOKING CHECKOUT FORM ================= */}
            {activeTab === 'booking' && selectedHotel && selectedRoom && (
              <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <button
                  onClick={() => setActiveTab('hotel_detail')}
                  className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 mb-6 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Hotel Details</span>
                </button>

                <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
                  <h1 className="text-2xl font-black text-slate-900 tracking-tight mb-2">
                    Complete Your Reservation
                  </h1>
                  <p className="text-xs text-slate-500 mb-6">
                    {selectedHotel.name} · {selectedRoom.name} ({nights} nights)
                  </p>

                  <form onSubmit={handleConfirmBooking} className="space-y-8">
                    {/* Guest Information */}
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">
                        1. Guest Information
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Full Name (Passport / Kebele ID)
                          </label>
                          <input
                            type="text"
                            required
                            value={guestName}
                            onChange={(e) => setGuestName(e.target.value)}
                            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Phone Number (+251 9... or international)
                          </label>
                          <input
                            type="tel"
                            required
                            value={guestPhone}
                            onChange={(e) => setGuestPhone(e.target.value)}
                            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Email Address (for booking confirmation voucher)
                          </label>
                          <input
                            type="email"
                            required
                            value={guestEmail}
                            onChange={(e) => setGuestEmail(e.target.value)}
                            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Special Requests / Flight Number for Bole Airport Shuttle
                          </label>
                          <textarea
                            rows={2}
                            value={specialRequests}
                            onChange={(e) => setSpecialRequests(e.target.value)}
                            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Payment Options */}
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">
                        2. Ethiopian Payment Options
                      </h3>
                      <div className="space-y-3">
                        {/* Option 1: Telebirr */}
                        <div
                          onClick={() => setPaymentMethod('telebirr')}
                          className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                            paymentMethod === 'telebirr'
                              ? 'border-blue-600 bg-blue-50/30'
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                                <Smartphone className="w-4 h-4" />
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-slate-900">Telebirr Mobile Payment</h4>
                                <p className="text-xs text-slate-500">Fast checkout via Ethio Telecom Telebirr super-app</p>
                              </div>
                            </div>
                            <input
                              type="radio"
                              name="payment"
                              checked={paymentMethod === 'telebirr'}
                              onChange={() => setPaymentMethod('telebirr')}
                              className="w-4 h-4 text-blue-600"
                            />
                          </div>

                          {paymentMethod === 'telebirr' && (
                            <div className="mt-3 pt-3 border-t border-blue-100">
                              <label className="block text-xs font-semibold text-slate-700 mb-1">
                                Telebirr Registered Phone Number
                              </label>
                              <input
                                type="tel"
                                value={telebirrMobile}
                                onChange={(e) => setTelebirrMobile(e.target.value)}
                                className="w-full max-w-xs px-3 py-2 rounded-lg border border-slate-300 text-sm font-medium"
                              />
                              <p className="text-[11px] text-slate-500 mt-1">
                                📱 A simulated Telebirr push/USSD prompt will be sent to confirm payment.
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Option 2: Bank Transfer */}
                        <div
                          onClick={() => setPaymentMethod('bank_transfer')}
                          className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                            paymentMethod === 'bank_transfer'
                              ? 'border-teal-600 bg-teal-50/30'
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs">
                                <Building className="w-4 h-4" />
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-slate-900">Bank Transfer (CBE / Awash / Abyssinia)</h4>
                                <p className="text-xs text-slate-500">Direct mobile bank transfer or cash deposit slip</p>
                              </div>
                            </div>
                            <input
                              type="radio"
                              name="payment"
                              checked={paymentMethod === 'bank_transfer'}
                              onChange={() => setPaymentMethod('bank_transfer')}
                              className="w-4 h-4 text-teal-600"
                            />
                          </div>

                          {paymentMethod === 'bank_transfer' && (
                            <div className="mt-3 pt-3 border-t border-teal-100 space-y-2">
                              <div className="p-3 rounded-lg bg-teal-50 text-xs font-mono text-slate-800">
                                <p className="font-bold text-teal-800">Commercial Bank of Ethiopia (CBE)</p>
                                <p>Account: 1000284729184</p>
                                <p>Account Name: StayEthio Hospitality PLC</p>
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">
                                  Transaction Reference / Slip #
                                </label>
                                <input
                                  type="text"
                                  value={bankRefCode}
                                  onChange={(e) => setBankRefCode(e.target.value)}
                                  className="w-full max-w-xs px-3 py-2 rounded-lg border border-slate-300 text-sm font-medium"
                                  placeholder="e.g. CBE-TX-998412"
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Option 3: Cash on Arrival */}
                        <div
                          onClick={() => setPaymentMethod('cash_on_arrival')}
                          className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                            paymentMethod === 'cash_on_arrival'
                              ? 'border-emerald-600 bg-emerald-50/30'
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                                <DollarSign className="w-4 h-4" />
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-slate-900">Cash on Arrival (Pay at Hotel Front Desk)</h4>
                                <p className="text-xs text-slate-500">Pay in Ethiopian Birr (ETB) or USD during check-in</p>
                              </div>
                            </div>
                            <input
                              type="radio"
                              name="payment"
                              checked={paymentMethod === 'cash_on_arrival'}
                              onChange={() => setPaymentMethod('cash_on_arrival')}
                              className="w-4 h-4 text-emerald-600"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Prototype Disclosure Banner */}
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2.5 text-xs text-slate-600">
                      <AlertCircle className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>
                        Prototype mode: simulated payments for testing & demonstration. Real accounts will not be charged.
                      </span>
                    </div>

                    {/* Total & Submit Button */}
                    <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div>
                        <span className="text-xs text-slate-400 font-medium block">Total Reservation Cost</span>
                        <span className="text-2xl font-black text-slate-900">
                          {formatPrice(selectedRoom.pricePerNightEtb * nights * 1.15)}
                        </span>
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmittingBooking}
                        className="w-full sm:w-auto px-8 py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm rounded-xl shadow-md transition-colors"
                      >
                        {isSubmittingBooking ? 'Confirming Stay...' : 'Confirm & Generate Voucher'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* ================= CUSTOMER BOOKINGS ("MY STAYS") ================= */}
            {activeTab === 'my_bookings' && (
              <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                      My Ethiopian Reservations
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-500">
                      Manage your upcoming hotel stays and view verified booking vouchers
                    </p>
                  </div>

                  <button
                    onClick={() => setActiveTab('home')}
                    className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    Explore More Hotels
                  </button>
                </div>

                {bookingsList.length === 0 ? (
                  <div className="text-center py-16 bg-slate-50 rounded-2xl border border-slate-200">
                    <Receipt className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                    <h3 className="text-base font-bold text-slate-800">No reservations yet</h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Explore our handpicked luxury hotels across Ethiopia and reserve your stay.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {bookingsList.map((booking) => (
                      <div
                        key={booking.id}
                        className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:shadow-md transition-shadow flex flex-col md:flex-row gap-5"
                      >
                        <img
                          src={booking.hotelImage}
                          alt={booking.hotelName}
                          className="w-full md:w-44 h-36 object-cover rounded-xl"
                        />

                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center justify-between gap-2">
                              <div>
                                <span className="text-xs font-mono font-bold text-teal-700">
                                  Ref: {booking.referenceCode}
                                </span>
                                <h3 className="text-lg font-bold text-slate-900">{booking.hotelName}</h3>
                              </div>

                              <span
                                className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                                  booking.bookingStatus === 'confirmed'
                                    ? 'bg-teal-50 text-teal-700'
                                    : booking.bookingStatus === 'cancelled'
                                    ? 'bg-red-50 text-red-600'
                                    : 'bg-slate-100 text-slate-700'
                                }`}
                              >
                                {booking.bookingStatus.toUpperCase()}
                              </span>
                            </div>

                            <p className="text-xs text-slate-600 font-semibold mt-1">
                              {booking.roomTypeName} · {booking.hotelCity}
                            </p>

                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 text-xs text-slate-500">
                              <div>
                                <span className="block text-[10px] text-slate-400 font-medium">Dates</span>
                                <span className="font-semibold text-slate-800">{booking.checkInDate} to {booking.checkOutDate}</span>
                              </div>
                              <div>
                                <span className="block text-[10px] text-slate-400 font-medium">Guests</span>
                                <span className="font-semibold text-slate-800">{booking.guestCount} Guests ({booking.nightsCount}N)</span>
                              </div>
                              <div>
                                <span className="block text-[10px] text-slate-400 font-medium">Payment</span>
                                <span className="font-semibold text-slate-800 capitalize">{booking.paymentType.replace('_', ' ')}</span>
                              </div>
                            </div>
                          </div>

                          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                            <div>
                              <span className="text-[11px] text-slate-400 font-medium block">Total Paid/Due</span>
                              <span className="text-base font-black text-slate-900">
                                {formatPrice(booking.totalAmountEtb)}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setVoucherModalBooking(booking)}
                                className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
                              >
                                <QrCode className="w-3.5 h-3.5" />
                                <span>View Voucher</span>
                              </button>

                              {booking.bookingStatus === 'confirmed' && (
                                <button
                                  onClick={() => handleCancelBooking(booking.id)}
                                  className="px-3 py-1.5 border border-red-200 text-red-600 hover:bg-red-50 rounded-lg text-xs font-semibold transition-colors"
                                >
                                  Cancel
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* ================= HOTEL OWNER DASHBOARD ================= */}
        {currentRole === 'owner' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
              <div>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                  Hotel Partner Portal
                </h1>
                <p className="text-xs sm:text-sm text-slate-500">
                  Manage your Ethiopian property listings, inventory, and guest reservations
                </p>
              </div>

              <button
                onClick={() => setShowAddHotelModal(true)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Hotel Listing</span>
              </button>
            </div>

            {/* Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-6">
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Gross Partner Revenue</span>
                <p className="text-2xl font-black text-slate-900 mt-1">
                  {formatPrice(bookingsList.filter(b => b.bookingStatus !== 'cancelled').sumOf ? 0 : bookingsList.reduce((acc, b) => b.bookingStatus !== 'cancelled' ? acc + b.totalAmountEtb : acc, 0))}
                </p>
                <span className="text-[11px] text-teal-600 font-semibold">Updated today</span>
              </div>
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Total Reservations</span>
                <p className="text-2xl font-black text-slate-900 mt-1">{bookingsList.length}</p>
                <span className="text-[11px] text-slate-500 font-semibold">Across all active rooms</span>
              </div>
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Partner Properties</span>
                <p className="text-2xl font-black text-slate-900 mt-1">{hotelsList.length}</p>
                <span className="text-[11px] text-emerald-600 font-semibold">Listed on StayEthio</span>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3 mb-6">
              <button
                onClick={() => setOwnerActiveTab('listings')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                  ownerActiveTab === 'listings'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                My Hotel Listings ({hotelsList.length})
              </button>
              <button
                onClick={() => setOwnerActiveTab('requests')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                  ownerActiveTab === 'requests'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Guest Booking Requests ({bookingsList.length})
              </button>
            </div>

            {ownerActiveTab === 'listings' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {hotelsList.map((hotel) => (
                  <div key={hotel.id} className="p-5 rounded-2xl border border-slate-200 bg-white flex gap-4">
                    <img src={hotel.mainImage} alt={hotel.name} className="w-28 h-28 object-cover rounded-xl" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-base font-bold text-slate-900">{hotel.name}</h3>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${hotel.isVerified ? 'bg-teal-50 text-teal-700' : 'bg-amber-50 text-amber-700'}`}>
                          {hotel.isVerified ? 'Active' : 'Pending Approval'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{hotel.city} · {hotel.subCityOrArea}</p>
                      <p className="text-xs font-black text-slate-900 mt-2">
                        {formatPrice(hotel.startingPriceEtb)} <span className="text-slate-400 font-normal">/ night</span>
                      </p>
                      <p className="text-[11px] text-teal-700 font-medium mt-1">
                        {hotel.rooms.length} room categories configured
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {bookingsList.map((b) => (
                  <div key={b.id} className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-900">{b.referenceCode}</span>
                        <span className="text-xs text-slate-500">· {b.guestFullName}</span>
                      </div>
                      <p className="text-xs font-semibold text-teal-800 mt-0.5">{b.hotelName} ({b.roomTypeName})</p>
                      <p className="text-[11px] text-slate-500 mt-1">
                        {b.checkInDate} to {b.checkOutDate} ({b.nightsCount} nights) · Phone: {b.guestPhone}
                      </p>
                      {b.specialRequests && (
                        <p className="text-[11px] text-slate-600 italic mt-0.5">Note: "{b.specialRequests}"</p>
                      )}
                    </div>

                    <div className="text-right flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto">
                      <span className="text-sm font-black text-slate-900">{formatPrice(b.totalAmountEtb)}</span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 font-bold mt-1">
                        {b.paymentType.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= ADMIN DASHBOARD ================= */}
        {currentRole === 'admin' && (
          currentUser?.role === 'admin' ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="pb-6 border-b border-slate-200">
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                StayEthio Platform Administration
              </h1>
              <p className="text-xs sm:text-sm text-slate-500">
                Platform metrics, partner verification queue, and transaction ledger
              </p>
            </div>

            {/* Admin Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 my-6">
              <div className="p-5 rounded-2xl bg-slate-900 text-white shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Gross Booking Volume</span>
                <p className="text-2xl font-black text-white mt-1">
                  {formatPrice(bookingsList.reduce((acc, b) => acc + b.totalAmountEtb, 0))}
                </p>
                <span className="text-[11px] text-teal-400">Total settled transactions</span>
              </div>
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Platform Take-rate (12%)</span>
                <p className="text-2xl font-black text-teal-700 mt-1">
                  {formatPrice(bookingsList.reduce((acc, b) => acc + b.totalAmountEtb, 0) * 0.12)}
                </p>
                <span className="text-[11px] text-slate-500">OTA Commission</span>
              </div>
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Verified Hotels</span>
                <p className="text-2xl font-black text-slate-900 mt-1">
                  {hotelsList.filter(h => h.isVerified).length} / {hotelsList.length}
                </p>
                <span className="text-[11px] text-emerald-600">Active online</span>
              </div>
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
                <span className="text-xs font-bold text-slate-400 uppercase">Total Bookings</span>
                <p className="text-2xl font-black text-slate-900 mt-1">{bookingsList.length}</p>
                <span className="text-[11px] text-slate-500">Reservations logged</span>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3 mb-6">
              <button
                onClick={() => setAdminActiveTab('approvals')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                  adminActiveTab === 'approvals'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Partner Verification Queue
              </button>
              <button
                onClick={() => setAdminActiveTab('ledger')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                  adminActiveTab === 'ledger'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Payment Ledger
              </button>
            </div>

            {adminActiveTab === 'approvals' ? (
              <div className="space-y-3">
                {hotelsList.map((hotel) => (
                  <div key={hotel.id} className="p-4 rounded-xl border border-slate-200 bg-white flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900">{hotel.name}</h4>
                        <span className="text-xs text-slate-500">· {hotel.city}</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Base: {formatPrice(hotel.startingPriceEtb)}/night · {hotel.rooms.length} room types
                      </p>
                    </div>

                    <button
                      onClick={() => handleToggleVerification(hotel.id)}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                        hotel.isVerified
                          ? 'bg-teal-50 text-teal-700 hover:bg-teal-100'
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      {hotel.isVerified ? 'Verified ✓' : 'Approve Partner'}
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {bookingsList.map((b) => (
                  <div key={b.id} className="p-3.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-slate-900">{b.referenceCode}</span>
                      <span className="text-slate-500 ml-2">{b.guestFullName} · {b.hotelName}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-semibold text-slate-600 capitalize">{b.paymentType.replace('_', ' ')}</span>
                      <span className="font-black text-slate-900">{formatPrice(b.totalAmountEtb)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          ) : (
            <div className="max-w-xl mx-auto px-4 py-20 text-center">
              <div className="w-16 h-16 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-4 border border-red-100">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                Admin Authorization Required
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed max-w-md mx-auto">
                The StayEthio Admin Console is restricted to authenticated system administrators.
                Ordinary traveler and hotel partner accounts do not have clearance to view platform ledgers or partner approvals.
              </p>
              <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => { setCurrentRole('guest'); setActiveTab('home'); }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Return to Traveler View
                </button>
                <button
                  onClick={() => { setAuthModalOpen(true); }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Sign In with Admin Account
                </button>
              </div>
            </div>
          )
        )}
      </main>

      {/* ================= VOUCHER MODAL ================= */}
      {voucherModalBooking && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="bg-slate-900 text-white p-6 relative">
              <button
                onClick={() => setVoucherModalBooking(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-teal-400 text-xs font-bold mb-1">
                <Check className="w-4 h-4" />
                <span>CONFIRMED RESERVATION</span>
              </div>
              <h3 className="text-xl font-black">StayEthio Voucher</h3>
              <p className="font-mono text-2xl font-black tracking-widest text-teal-300 mt-2">
                {voucherModalBooking.referenceCode}
              </p>
            </div>

            {/* Voucher Details */}
            <div className="p-6 space-y-4 text-xs">
              <div className="pb-4 border-b border-slate-100 flex items-center gap-3">
                <img
                  src={voucherModalBooking.hotelImage}
                  alt={voucherModalBooking.hotelName}
                  className="w-16 h-16 rounded-xl object-cover"
                />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{voucherModalBooking.hotelName}</h4>
                  <p className="text-slate-500">{voucherModalBooking.hotelCity}</p>
                  <p className="font-semibold text-teal-700 mt-0.5">{voucherModalBooking.roomTypeName}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-xl">
                <div>
                  <span className="text-[10px] text-slate-400 font-medium block">Check-in</span>
                  <span className="font-bold text-slate-900">{voucherModalBooking.checkInDate}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-medium block">Check-out</span>
                  <span className="font-bold text-slate-900">{voucherModalBooking.checkOutDate}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-medium block">Guests</span>
                  <span className="font-bold text-slate-900">{voucherModalBooking.guestCount} Guests</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-medium block">Length</span>
                  <span className="font-bold text-slate-900">{voucherModalBooking.nightsCount} Nights</span>
                </div>
              </div>

              <div className="space-y-1.5 text-slate-600">
                <div className="flex justify-between">
                  <span>Guest Name:</span>
                  <span className="font-semibold text-slate-900">{voucherModalBooking.guestFullName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Contact Phone:</span>
                  <span className="font-semibold text-slate-900">{voucherModalBooking.guestPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Method:</span>
                  <span className="font-semibold text-slate-900 capitalize">{voucherModalBooking.paymentType.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Status:</span>
                  <span className="font-bold text-teal-700">{voucherModalBooking.paymentStatus}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-100">
                  <span>Total Amount:</span>
                  <span className="text-teal-700">{formatPrice(voucherModalBooking.totalAmountEtb)}</span>
                </div>
              </div>

              {/* QR Mock Frame */}
              <div className="py-3 px-4 border border-dashed border-slate-300 rounded-xl flex items-center justify-center flex-col">
                <QrCode className="w-16 h-16 text-slate-800" />
                <span className="text-[10px] text-slate-500 mt-1">Present this digital voucher at hotel reception</span>
              </div>

              <button
                onClick={() => setVoucherModalBooking(null)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold transition-colors"
              >
                Close Voucher
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= FILTER MODAL ================= */}
      {showFilterModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Filter Hotels</h3>
              <button onClick={() => setShowFilterModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-5">
              {/* Star Rating */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Star Rating</label>
                <div className="grid grid-cols-4 gap-2">
                  {[null, 3, 4, 5].map((star) => (
                    <button
                      key={star ?? 'any'}
                      onClick={() => setSelectedStars(star)}
                      className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                        selectedStars === star
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {star ? `${star} ★` : 'Any'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Slider */}
              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-2">
                  <span>Max Nightly Rate</span>
                  <span className="text-teal-700">{formatPrice(maxPrice)}</span>
                </div>
                <input
                  type="range"
                  min="5000"
                  max="35000"
                  step="1000"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  className="w-full accent-teal-600"
                />
              </div>

              {/* Amenity Filter */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Featured Amenity</label>
                <select
                  value={filterAmenity}
                  onChange={(e) => setFilterAmenity(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 bg-slate-50"
                >
                  <option value="">Any Amenity</option>
                  <option value="Shuttle">Free Airport Shuttle</option>
                  <option value="Pool">Swimming Pool</option>
                  <option value="Buna">Buna Coffee Ceremony</option>
                  <option value="Spa">Full Service Spa</option>
                  <option value="WiFi">High-Speed WiFi</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  setSelectedStars(null);
                  setMaxPrice(35000);
                  setFilterAmenity('');
                  setShowFilterModal(false);
                }}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50"
              >
                Reset
              </button>
              <button
                onClick={() => setShowFilterModal(false)}
                className="flex-1 py-2 rounded-xl bg-teal-600 text-white text-xs font-bold hover:bg-teal-700"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= ADD HOTEL MODAL ================= */}
      {showAddHotelModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add New Hotel Listing</h3>
              <button onClick={() => setShowAddHotelModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddHotel} className="py-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Hotel or Lodge Name</label>
                <input
                  type="text"
                  required
                  value={newHotelName}
                  onChange={(e) => setNewHotelName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">City</label>
                  <select
                    value={newHotelCity}
                    onChange={(e) => setNewHotelCity(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-slate-50"
                  >
                    {ETHIOPIAN_CITIES.filter(c => c !== 'All Cities').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Area / Sub-city</label>
                  <input
                    type="text"
                    required
                    value={newHotelArea}
                    onChange={(e) => setNewHotelArea(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Street Address</label>
                <input
                  type="text"
                  required
                  value={newHotelAddress}
                  onChange={(e) => setNewHotelAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Starting Price per Night (ETB)</label>
                <input
                  type="number"
                  required
                  value={newHotelPrice}
                  onChange={(e) => setNewHotelPrice(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  required
                  value={newHotelDesc}
                  onChange={(e) => setNewHotelDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Submit Listing for Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-900 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center font-bold text-white text-sm">
                SE
              </div>
              <span className="text-white font-black text-lg tracking-tight">StayEthio</span>
              <span className="text-slate-600">·</span>
              <span className="text-xs text-slate-400">Authentic Ethiopian Hospitality</span>
            </div>

            <div className="flex items-center gap-6 text-xs font-medium">
              <span>Addis Ababa</span>
              <span>Bishoftu</span>
              <span>Lalibela</span>
              <span>Bahir Dar</span>
              <span>Hawassa</span>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-4">
            <p>© {new Date().getFullYear()} StayEthio Hospitality Technologies PLC. All rights reserved.</p>
            <p>Integrated with Telebirr, Commercial Bank of Ethiopia (CBE), and cash settlements.</p>
          </div>
        </div>
      </footer>

      {/* Auth Modal when opened from navigation */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-md">
            <button
              onClick={() => setAuthModalOpen(false)}
              className="absolute top-4 right-4 z-50 p-2 text-slate-400 hover:text-slate-600 bg-white rounded-full shadow-md cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <AuthScreens
              initialMode="login"
              onLoginSuccess={handleAuthSuccess}
              onExploreAsGuest={() => setAuthModalOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
