export type UserRole = 'guest' | 'owner' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  isLoggedIn: boolean;
}

export type PaymentMethod = 'telebirr' | 'bank_transfer' | 'cash_on_arrival';

export type BookingStatus = 'confirmed' | 'pending' | 'checked_in' | 'completed' | 'cancelled';

export interface RoomType {
  id: string;
  name: string;
  description: string;
  bedType: string;
  maxGuests: number;
  pricePerNightEtb: number;
  sizeSqMeters: number;
  amenities: string[];
  image: string;
}

export interface Review {
  id: string;
  authorName: string;
  cityOrCountry: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Hotel {
  id: string;
  name: string;
  city: string;
  subCityOrArea: string;
  fullAddress: string;
  starRating: number;
  reviewScore: number;
  reviewCount: number;
  startingPriceEtb: number;
  mainImage: string;
  galleryImages: string[];
  description: string;
  highlights: string[];
  amenities: string[];
  rooms: RoomType[];
  isFeatured: boolean;
  isVerified: boolean;
  ownerId: string;
  distanceToAirportKm?: number;
}

export interface Booking {
  id: string;
  referenceCode: string;
  hotelId: string;
  hotelName: string;
  hotelCity: string;
  hotelImage: string;
  roomTypeName: string;
  checkInDate: string;
  checkOutDate: string;
  nightsCount: number;
  guestCount: number;
  guestFullName: string;
  guestPhone: string;
  guestEmail: string;
  specialRequests: string;
  subtotalEtb: number;
  taxesEtb: number;
  totalAmountEtb: number;
  paymentType: PaymentMethod;
  paymentStatus: string;
  bookingStatus: BookingStatus;
  createdAt: string;
  bankTransactionRef?: string;
  telebirrPhone?: string;
}
